import { CAMPUSES } from './campuses';
import type { CameraAngle, CampusId, NormalizedBox, VisionFeed } from '../types';

export const CAMERA_ANGLES: readonly CameraAngle[] = ['NE', 'NW', 'SE', 'SW'];

function bayGrid(): NormalizedBox[] {
  const boxes: NormalizedBox[] = [];
  for (let row = 0; row < 2; row += 1) {
    for (let column = 0; column < 12; column += 1) {
      boxes.push({
        x: 0.025 + column * 0.081,
        y: 0.18 + row * 0.48,
        w: 0.058,
        h: 0.17,
      });
    }
  }
  return boxes;
}

function cameraLevel(levels: number, angle: CameraAngle): number {
  if (angle === 'NE') return levels;
  if (angle === 'NW') return Math.max(1, levels - 1);
  if (angle === 'SE') return Math.min(2, levels);
  return 1;
}

export const VISION_FEEDS: readonly VisionFeed[] = Object.values(CAMPUSES).flatMap((campus) =>
  campus.decks.flatMap((deck) =>
    CAMERA_ANGLES.map((angle) => ({
      id: `${deck.id}-${angle.toLowerCase()}`,
      campusId: deck.campusId,
      deckId: deck.id,
      deckName: deck.name,
      level: cameraLevel(deck.levels, angle),
      angle,
      label: `${deck.name} · L${cameraLevel(deck.levels, angle)} · ${angle} elevation`,
      bayGrid: bayGrid(),
    })),
  ),
);

export function getVisionFeed(feedId: string): VisionFeed {
  const feed = VISION_FEEDS.find((candidate) => candidate.id === feedId);
  const fallback = VISION_FEEDS[0];
  if (!fallback) throw new Error('OwlFlow requires at least one vision feed.');
  return feed ?? fallback;
}

export function getDeckFeeds(deckId: string): VisionFeed[] {
  return VISION_FEEDS.filter((feed) => feed.deckId === deckId);
}

export function getCampusFeeds(campusId: CampusId): VisionFeed[] {
  return VISION_FEEDS.filter((feed) => feed.campusId === campusId);
}
