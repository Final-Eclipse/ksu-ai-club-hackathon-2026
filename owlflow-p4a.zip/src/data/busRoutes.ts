import type { BusTrackerRoute } from '../types';

export const BUS_ROUTES: readonly BusTrackerRoute[] = [
  {
    id: 'ksu-express',
    name: 'Kennesaw–Marietta Express',
    color: '#FDBB30',
    headwayMin: 18,
    path: [
      { x: 175, y: 128 },
      { x: 270, y: 175 },
      { x: 385, y: 245 },
      { x: 515, y: 315 },
      { x: 650, y: 378 },
      { x: 796, y: 430 },
    ],
    stops: [
      { id: 'express-rec', name: 'KSU Bookstore / Rec Center', x: 175, y: 128 },
      { id: 'express-commons', name: 'The Commons', x: 270, y: 175 },
      { id: 'express-wilson', name: 'Joe Mack Wilson Student Center', x: 796, y: 430 },
    ],
    buses: [
      { id: 'express-1', label: 'Express 01', speed: 0.000022 },
      { id: 'express-2', label: 'Express 02', speed: 0.000019 },
    ],
  },
  {
    id: 'marietta-loop',
    name: 'Marietta Loop',
    color: '#38BDF8',
    headwayMin: 8,
    path: [
      { x: 690, y: 382 },
      { x: 800, y: 430 },
      { x: 875, y: 390 },
      { x: 858, y: 492 },
      { x: 738, y: 502 },
      { x: 690, y: 382 },
    ],
    stops: [
      { id: 'mloop-wilson', name: 'Wilson Student Center', x: 800, y: 430 },
      { id: 'mloop-stingers', name: 'Stingers', x: 858, y: 492 },
      { id: 'mloop-hornet', name: 'Hornet Village', x: 738, y: 502 },
    ],
    buses: [{ id: 'mloop-1', label: 'Marietta 11', speed: 0.000034 }],
  },
  {
    id: 'chastain-loop',
    name: 'Chastain Pointe / Rec Center',
    color: '#10B981',
    headwayMin: 12,
    path: [
      { x: 112, y: 72 },
      { x: 188, y: 125 },
      { x: 302, y: 105 },
      { x: 350, y: 182 },
      { x: 245, y: 217 },
      { x: 130, y: 170 },
      { x: 112, y: 72 },
    ],
    stops: [
      { id: 'chastain-point', name: 'Chastain Pointe', x: 112, y: 72 },
      { id: 'chastain-rec', name: 'Rec Center / Bookstore', x: 188, y: 125 },
      { id: 'chastain-commons', name: 'The Commons', x: 350, y: 182 },
    ],
    buses: [
      { id: 'chastain-1', label: 'Chastain 21', speed: 0.000031 },
      { id: 'chastain-2', label: 'Chastain 22', speed: 0.000028 },
    ],
  },
];

export function getBusRoute(routeId?: string): BusTrackerRoute {
  const route = routeId ? BUS_ROUTES.find((candidate) => candidate.id === routeId) : undefined;
  const fallback = BUS_ROUTES[0];
  if (!fallback) throw new Error('OwlFlow requires at least one bus route.');
  return route ?? fallback;
}
