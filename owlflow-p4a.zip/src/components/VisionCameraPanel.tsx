import { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Camera,
  CheckCircle2,
  Cloud,
  LoaderCircle,
  RotateCcw,
  ScanLine,
  Upload,
  Video,
} from 'lucide-react';
import { getVisionFeed } from '../data/visionFeeds';
import { geminiAvailable } from '../engine/gemini';
import { formatClockWithSeconds } from '../engine/time';
import {
  analyzeFrameGemini,
  analyzeFrameLocal,
  getVisionLevel,
  simulateVisionFeed,
  simulatedCarColor,
} from '../engine/vision';
import { useNowSeconds } from '../hooks/useNowSeconds';
import type {
  CameraSelection,
  CvOverride,
  DeckReading,
  EngineMode,
  Scenario,
  VisionResult,
  VisionSource,
} from '../types';

interface VisionCameraPanelProps {
  camera: CameraSelection;
  readings: readonly DeckReading[];
  scenario: Scenario;
  minute: number;
  override?: CvOverride;
  onPush: (deckId: string, level: number, result: VisionResult) => void;
  onClear: (deckId: string, level: number) => void;
  onBack: () => void;
}

export function VisionCameraPanel({
  camera,
  readings,
  scenario,
  minute,
  override,
  onPush,
  onClear,
  onBack,
}: VisionCameraPanelProps) {
  const feed = getVisionFeed(`${camera.deckId}-${camera.angle.toLowerCase()}`);
  const level = getVisionLevel(readings, feed.deckId, feed.level);
  const simulatedResult = useMemo(
    () => simulateVisionFeed(feed, level, scenario, minute),
    [feed, level, minute, scenario],
  );
  const [source, setSource] = useState<VisionSource>('simulated');
  const [engine, setEngine] = useState<EngineMode>('local');
  const [videoFile, setVideoFile] = useState<File>();
  const [videoUrl, setVideoUrl] = useState('');
  const [result, setResult] = useState<VisionResult>(simulatedResult);
  const [analyzing, setAnalyzing] = useState(false);
  const [message, setMessage] = useState('Simulated live feed is synchronized with this level (SIM).');
  const [decodeError, setDecodeError] = useState('');
  const nowSeconds = useNowSeconds();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const backRef = useRef<HTMLButtonElement>(null);
  const controllerRef = useRef<AbortController | null>(null);
  const frameRef = useRef<number | null>(null);
  const decodedRef = useRef(false);

  useEffect(() => {
    setSource('simulated');
    setVideoFile(undefined);
    setResult(simulatedResult);
    setMessage('Simulated live feed is synchronized with this level (SIM).');
    setDecodeError('');
    controllerRef.current?.abort();
  }, [feed.id, simulatedResult]);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => backRef.current?.focus());
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.stopPropagation();
      onBack();
    };
    document.addEventListener('keydown', onKeyDown);
    return () => {
      window.cancelAnimationFrame(frame);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [onBack]);

  useEffect(() => {
    if (!videoFile) {
      setVideoUrl('');
      return;
    }
    const url = URL.createObjectURL(videoFile);
    setVideoUrl(url);
    decodedRef.current = false;
    return () => URL.revokeObjectURL(url);
  }, [videoFile]);

  useEffect(() => {
    if (!videoUrl || source !== 'upload') return;
    const timeout = window.setTimeout(() => {
      if (!decodedRef.current) setDecodeError("This browser can't play this file — re-export as H.264 MP4");
    }, 5000);
    return () => window.clearTimeout(timeout);
  }, [source, videoUrl]);

  useEffect(() => () => {
    controllerRef.current?.abort();
    if (frameRef.current !== null) window.cancelAnimationFrame(frameRef.current);
  }, []);

  const acceptFile = (candidate: unknown) => {
    if (!(candidate instanceof File)) return;
    if (!['video/mp4', 'video/quicktime', 'video/webm'].includes(candidate.type)) {
      setDecodeError('Use an MP4, MOV, or WebM video file.');
      return;
    }
    setVideoFile(candidate);
    setSource('upload');
    setResult(simulatedResult);
    setDecodeError('');
    setMessage(`${candidate.name} loaded locally. No upload has occurred.`);
  };

  const captureFrame = async (): Promise<{ imageData: ImageData; jpeg: string } | null> => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    return new Promise((resolve) => {
      frameRef.current = window.requestAnimationFrame(() => {
        try {
          const context = canvas.getContext('2d', { willReadFrequently: true });
          const video = videoRef.current;
          if (!context || !video || video.readyState < 2) {
            frameRef.current = null;
            resolve(null);
            return;
          }
          const scale = Math.min(1, 768 / video.videoWidth);
          canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
          canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
          context.drawImage(video, 0, 0, canvas.width, canvas.height);
          const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
          const jpeg = canvas.toDataURL('image/jpeg', 0.82).split(',')[1] ?? '';
          frameRef.current = null;
          resolve({ imageData, jpeg });
        } catch {
          frameRef.current = null;
          resolve(null);
        }
      });
    });
  };

  const analyzeUpload = async () => {
    setAnalyzing(true);
    setMessage('Capturing and analyzing one frame…');
    const frame = await captureFrame();
    if (!frame) {
      setAnalyzing(false);
      setMessage("This browser can't play this file — re-export as H.264 MP4");
      return;
    }
    const local = analyzeFrameLocal(feed, frame.imageData, `${scenario.id}|${minute}|L${level.level}`);
    let nextResult = local;
    if (engine === 'gemini' && geminiAvailable() && frame.jpeg) {
      controllerRef.current?.abort();
      const controller = new AbortController();
      controllerRef.current = controller;
      const timeout = window.setTimeout(() => controller.abort(), 8000);
      try {
        nextResult = await analyzeFrameGemini(frame.jpeg, feed, controller.signal);
        setMessage('Live Gemini analyzed one frame. The frame was not stored.');
      } catch {
        nextResult = local;
        setMessage('Gemini unavailable → Fast Local completed the frame.');
      } finally {
        window.clearTimeout(timeout);
        controllerRef.current = null;
      }
    } else if (engine === 'gemini') {
      setMessage('Gemini unavailable → Fast Local completed the frame.');
    } else {
      setMessage('Fast Local analyzed the frame entirely in this browser.');
    }
    setResult(nextResult);
    setAnalyzing(false);
  };

  return (
    <section className="ps-camera-viewer" aria-labelledby="ps-camera-viewer-title">
      <div className="ps-camera-viewer__head">
        <button ref={backRef} type="button" onClick={onBack}><ArrowLeft size={16} /> Back to Map</button>
        <div><small>Parking Camera Footage Viewer</small><h2 id="ps-camera-viewer-title">{feed.deckName} · Camera {feed.angle} · Level {feed.level}</h2></div>
        <span><i /> LIVE · SIM</span>
        <time>{formatClockWithSeconds(nowSeconds)}</time>
      </div>

      <div className="ps-camera-source-tabs" role="group" aria-label="Camera footage source">
        <button type="button" aria-pressed={source === 'simulated'} onClick={() => { setSource('simulated'); setResult(simulatedResult); setMessage('Simulated live feed is synchronized with this level (SIM).'); }}><Camera size={14} /> Simulated live feed</button>
        <button type="button" aria-pressed={source === 'upload'} onClick={() => setSource('upload')}><Upload size={14} /> Upload footage</button>
      </div>

      <div className={`ps-camera-stage ps-camera-stage--${source}`} onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); acceptFile(event.dataTransfer.files.item(0)); }}>
        {source === 'simulated' ? (
          <svg viewBox="0 0 960 540" role="img" aria-label={`Simulated ${feed.deckName} level ${feed.level} parking camera`}>
            <defs><linearGradient id={`ps-camera-floor-${feed.id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#343945" /><stop offset="1" stopColor="#111318" /></linearGradient></defs>
            <rect width="960" height="540" fill={`url(#ps-camera-floor-${feed.id})`} />
            <polygon points="30,115 930,115 850,500 110,500" fill="#1B1E25" stroke="#667085" strokeWidth="3" />
            <rect x="45" y="255" width="870" height="105" rx="8" fill="#282D36" />
            <path d="M55 307h850" stroke="#FDBB30" strokeWidth="3" strokeDasharray="24 18" opacity=".55" />
            {result.boxes.map((box, index) => {
              const x = box.x * 960;
              const y = box.y * 540;
              const width = box.w * 960;
              const height = box.h * 540;
              return (
                <g key={`${feed.id}-stall-${index}`}>
                  <rect x={x} y={y} width={width} height={height} rx="4" fill="none" stroke={box.state === 'open' ? '#10B981' : '#DC2626'} strokeWidth="3" />
                  {box.state === 'occupied' && <g><rect x={x + width * .12} y={y + height * .18} width={width * .76} height={height * .64} rx="7" fill={simulatedCarColor(feed, index, scenario, minute)} /><rect x={x + width * .24} y={y + height * .24} width={width * .52} height={height * .18} rx="3" fill="#A3A8B3" opacity=".65" /></g>}
                  <text x={x + 4} y={y - 5} fill={box.state === 'open' ? '#6EE7B7' : '#FCA5A5'} fontSize="10" fontWeight="800">{box.state.toUpperCase()}</text>
                </g>
              );
            })}
            <text x="35" y="45" fill="#FDBB30" fontSize="18" fontWeight="900">{feed.angle} ELEVATION · L{feed.level} · SIM</text>
          </svg>
        ) : videoUrl ? (
          <video ref={videoRef} src={videoUrl} controls playsInline muted onLoadedData={() => { decodedRef.current = true; setDecodeError(''); }} onError={() => setDecodeError("This browser can't play this file — re-export as H.264 MP4")} />
        ) : (
          <button type="button" className="ps-video-drop" onClick={() => inputRef.current?.click()}><Upload size={27} /><strong>Drop MP4, MOV, or WebM footage</strong><small>or choose a local file</small></button>
        )}
        {source === 'upload' && result && <div className="ps-vision-boxes">{result.boxes.map((box, index) => <i key={`${feed.id}-box-${index}`} className={`ps-vision-box ps-vision-box--${box.state}`} style={{ left: `${box.x * 100}%`, top: `${box.y * 100}%`, width: `${box.w * 100}%`, height: `${box.h * 100}%` }}><span>{box.state}</span></i>)}</div>}
        <span className="ps-camera-scanline" aria-hidden="true" />
      </div>
      <input ref={inputRef} className="ps-sr-only" type="file" accept="video/mp4,video/quicktime,video/webm" onChange={(event) => acceptFile(event.target.files?.item(0) ?? null)} />
      <canvas ref={canvasRef} className="ps-vision-canvas" aria-hidden="true" />
      {decodeError && <p className="ps-camera-error" role="alert">{decodeError}</p>}

      <div className="ps-camera-stats">
        <div><strong>In view: {result.open} open / {result.total}</strong><small>24-stall camera sample · SIM</small></div>
        <div><strong>Level {level.level}: {level.open} / {level.capacity}</strong><small>Effective level reading</small></div>
        <div><strong>{Math.round(result.confidence * 100)}%</strong><small>{result.engine === 'gemini' ? 'Gemini' : 'Fast Local'} confidence</small></div>
      </div>

      {source === 'upload' && <div className="ps-camera-analysis"><div className="ps-vision-segmented" role="group" aria-label="Vision engine"><button type="button" aria-pressed={engine === 'local'} onClick={() => setEngine('local')}><ScanLine size={13} /> Fast Local</button><button type="button" aria-pressed={engine === 'gemini'} onClick={() => setEngine('gemini')}><Cloud size={13} /> Live Gemini</button></div><button type="button" disabled={analyzing || !videoUrl || Boolean(decodeError)} onClick={() => { analyzeUpload().catch(() => setMessage('Frame analysis failed.')); }}>{analyzing ? <LoaderCircle className="ps-spin" size={15} /> : <Video size={15} />} Analyze frame</button></div>}
      <p className="ps-vision-message" role="status">{message} · frame-only, not stored</p>
      <div className="ps-camera-actions">
        <button type="button" onClick={() => onPush(feed.deckId, level.level, result)}><CheckCircle2 size={15} /> Push Detected Spots to OwlFlow</button>
        {override && <button type="button" onClick={() => onClear(feed.deckId, level.level)}><RotateCcw size={14} /> Clear level override</button>}
      </div>
    </section>
  );
}
