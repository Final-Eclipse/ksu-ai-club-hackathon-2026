import {
  BatteryCharging,
  Building2,
  BusFront,
  Camera,
  Layers3,
  Map as MapIcon,
  MapPin,
  Navigation,
  RotateCcw,
  ScanLine,
  X,
} from 'lucide-react';
import { EV_CHARGERS } from '../data/evChargers';
import { getCampusStreets } from '../data/streets';
import { CAMERA_ANGLES, getVisionFeed } from '../data/visionFeeds';
import { getCommuteOption } from '../engine/commute';
import { appleDirectionsUrl, googleDirectionsUrl } from '../engine/directions';
import {
  cameraPinPoint,
  facilitySpotDots,
  parkingBayCells,
  projectFootprint,
  projectGeo,
  projectGeo2d,
  routePath,
  sequence,
} from '../engine/mapLayout';
import { resolveMapInfo } from '../engine/mapInfo';
import type {
  CameraSelection,
  Campus,
  CampusMapMode,
  CampusMapView,
  CommuteDecision,
  CvOverrides,
  DeckReading,
  EvChargerReading,
  JourneyPlan,
  MapFocus,
  Place,
  Scenario,
  VisionResult,
} from '../types';
import { BusTracker } from './BusTracker';
import { StatusBadge } from './StatusBadge';
import { VisionCameraPanel } from './VisionCameraPanel';

interface CampusMapProps {
  campus: Campus;
  target: Place;
  readings: readonly DeckReading[];
  allReadings: readonly DeckReading[];
  evReadings: readonly EvChargerReading[];
  decision: CommuteDecision;
  journey: JourneyPlan;
  scenario: Scenario;
  minute: number;
  mode: CampusMapMode;
  view: CampusMapView;
  focus: MapFocus | null;
  camera: CameraSelection | null;
  cvOverrides: CvOverrides;
  onModeChange: (mode: CampusMapMode) => void;
  onViewChange: (view: CampusMapView) => void;
  onFocusChange: (focus: MapFocus | null) => void;
  onCameraChange: (camera: CameraSelection | null) => void;
  onApplyCvOverride: (deckId: string, level: number, result: VisionResult) => void;
  onClearCvOverride: (deckId: string, level?: number) => void;
}

export function CampusMap({
  campus,
  target,
  readings,
  allReadings,
  evReadings,
  decision,
  journey,
  scenario,
  minute,
  mode,
  view,
  focus,
  camera,
  cvOverrides,
  onModeChange,
  onViewChange,
  onFocusChange,
  onCameraChange,
  onApplyCvOverride,
  onClearCvOverride,
}: CampusMapProps) {
  const selectedOption = getCommuteOption(decision, decision.winner);
  const targetPoint3d = projectGeo(campus, target.geo);
  const arrivalPoint3d = projectGeo(campus, selectedOption.arrivalPoint.geo);
  const targetPoint2d = projectGeo2d(campus, target.geo);
  const arrivalPoint2d = projectGeo2d(campus, selectedOption.arrivalPoint.geo);
  const streets = getCampusStreets(campus.id);
  const chargers = EV_CHARGERS.filter((charger) => charger.campusId === campus.id);
  const mapInfo = resolveMapInfo(focus, campus, target, readings, evReadings);
  const cameraFeed = camera ? getVisionFeed(`${camera.deckId}-${camera.angle.toLowerCase()}`) : null;
  const cameraOverride = cameraFeed ? cvOverrides[cameraFeed.deckId]?.[cameraFeed.level] : undefined;
  const journeyPoints = journey.stops.map((stop) => projectGeo2d(campus, stop.geo)).map((point) => `${point.x},${point.y}`).join(' ');

  return (
    <section className="ps-map-section ps-map-section--p3" aria-labelledby="ps-map-title">
      <div className="ps-section-label"><span>04</span> KSU Campus Map</div>
      <div className="ps-map-mode-head">
        <div><p className="ps-kicker">Campus intelligence map</p><h1 id="ps-map-title">Know where to move next.</h1><p>Local KSU geometry, synchronized parking counts, EV availability, camera views, and simulated campus transit.</p></div>
        {!camera && <div className="ps-map-toggle-stack"><div className="ps-map-mode-toggle" role="group" aria-label="Campus map mode"><button type="button" aria-pressed={mode === 'parking'} onClick={() => onModeChange('parking')}><Camera size={15} /> Parking &amp; Cameras</button><button type="button" aria-pressed={mode === 'bus'} onClick={() => onModeChange('bus')}><BusFront size={15} /> Live Big Owl Bus</button></div>{mode === 'parking' && <div className="ps-map-mode-toggle ps-map-view-toggle" role="group" aria-label="Campus map view"><button type="button" aria-pressed={view === '2d'} onClick={() => onViewChange('2d')}><MapIcon size={15} /> 2D Map</button><button type="button" aria-pressed={view === '3d'} onClick={() => onViewChange('3d')}><Layers3 size={15} /> 3D View</button></div>}</div>}
      </div>

      {camera && cameraFeed ? (
        <VisionCameraPanel
          camera={camera}
          readings={allReadings}
          scenario={scenario}
          minute={minute}
          {...(cameraOverride ? { override: cameraOverride } : {})}
          onPush={onApplyCvOverride}
          onClear={(deckId, level) => onClearCvOverride(deckId, level)}
          onBack={() => onCameraChange(null)}
        />
      ) : mode === 'bus' ? (
        <BusTracker scenario={scenario} campusId={campus.id} minute={minute} />
      ) : (
        <div className="ps-map-p3-layout">
          <div className="ps-map-shell">
            <div className="ps-map-toolbar"><span><MapPin size={14} /> {campus.name} · north up</span><span><Navigation size={14} /> AI route: {selectedOption.title}</span><span className="ps-sim-chip">COUNTS · SIM</span></div>
            <div className={`ps-map-scroll ps-map-scroll--${view}`}>
              {view === '2d' ? (
                <svg className="ps-campus-map ps-campus-map--2d" viewBox="0 0 1000 600" role="img" aria-label={`${campus.name} two-dimensional campus map`}>
                  <rect width="1000" height="600" rx="18" className="ps-map2d-bg" />
                  <path d="M70 100H930V525H70Z" className="ps-map2d-campus" />
                  {streets.map((street) => {
                    const points = street.points.map((point) => projectGeo2d(campus, point));
                    const polyline = points.map((point) => `${point.x},${point.y}`).join(' ');
                    const labelPoint = points[Math.floor(points.length / 2)];
                    return <g key={street.id} className="ps-map2d-street"><polyline className="ps-map2d-road-casing" points={polyline} /><polyline className="ps-map2d-road" points={polyline} />{labelPoint && <text x={labelPoint.x} y={labelPoint.y - 8}>{street.name}</text>}</g>;
                  })}
                  {journeyPoints && <polyline className="ps-map2d-journey" points={journeyPoints} />}
                  {!journeyPoints && <path className="ps-map2d-journey" d={routePath(arrivalPoint2d, targetPoint2d)} />}

                  {campus.places.map((place) => {
                    const point = projectGeo2d(campus, place.geo);
                    const footprint = projectFootprint(place.footprint);
                    const selected = place.id === target.id;
                    return <g key={place.id} className={selected ? 'ps-map2d-building ps-map2d-building--target' : 'ps-map2d-building'}><rect x={point.x - footprint.width / 2} y={point.y - footprint.depth / 2} width={footprint.width} height={footprint.depth} rx="4" /><text x={point.x} y={point.y + footprint.depth / 2 + 14} textAnchor="middle">{place.short}</text></g>;
                  })}

                  {campus.decks.map((deck) => {
                    const reading = readings.find((candidate) => candidate.deckId === deck.id);
                    if (!reading) return null;
                    const point = projectGeo2d(campus, deck.geo);
                    const footprint = projectFootprint(deck.footprint);
                    const selected = focus?.kind === 'deck' && focus.id === deck.id;
                    const deckOverrides = cvOverrides[deck.id];
                    const levelMax = Math.max(1, ...reading.levels.map((level) => level.open / Math.max(1, level.capacity)));
                    return (
                      <g key={deck.id} className={selected ? 'ps-map2d-deck ps-map2d-deck--selected' : 'ps-map2d-deck'} role="button" tabIndex={0} aria-label={`${deck.name}, ${reading.open} open`} onClick={() => onFocusChange({ kind: 'deck', id: deck.id })} onKeyDown={(event) => { if (event.key !== 'Enter' && event.key !== ' ') return; event.preventDefault(); onFocusChange({ kind: 'deck', id: deck.id }); }}>
                        <rect x={point.x - footprint.width / 2 - 5} y={point.y - footprint.depth / 2 - 5} width={footprint.width + 10} height={footprint.depth + 10} rx="8" />
                        {facilitySpotDots(deck, reading).map((spot) => {
                          const spotPoint = projectGeo2d(campus, spot.geo);
                          return <circle key={spot.id} className={spot.open ? 'ps-map2d-spot ps-map2d-spot--open' : 'ps-map2d-spot'} cx={spotPoint.x} cy={spotPoint.y} r={spot.open ? 5 : 3} onClick={spot.open ? (event) => { event.stopPropagation(); onFocusChange({ kind: 'spot', id: spot.id }); } : undefined}><title>{spot.open ? 'Open representative spot' : 'Occupied representative spot'} · SIM</title></circle>;
                        })}
                        <g className="ps-map2d-deck-pill" transform={`translate(${point.x - footprint.width / 2} ${point.y - footprint.depth / 2 - 24})`}><rect width={Math.max(112, footprint.width)} height="19" rx="9" /><text x="8" y="13">{deck.short} · {reading.open} open</text></g>
                        <g className="ps-map2d-levelbar" transform={`translate(${point.x - footprint.width / 2} ${point.y + footprint.depth / 2 + 8})`}>{reading.levels.map((level, index) => <rect key={level.level} x={index * (footprint.width / reading.levels.length)} width={Math.max(3, footprint.width / reading.levels.length - 2)} height="5" rx="2" opacity={.25 + .75 * ((level.open / Math.max(1, level.capacity)) / levelMax)} />)}</g>
                        {deckOverrides && Object.keys(deckOverrides).length > 0 && <text className="ps-svg-cv-chip" x={point.x} y={point.y - footprint.depth / 2 - 30} textAnchor="middle">CV</text>}
                        {CAMERA_ANGLES.map((angle) => { const pin = cameraPinPoint(point, angle); return <g key={`${deck.id}-${angle}`} className="ps-camera-pin" transform={`translate(${pin.x} ${pin.y})`} role="button" tabIndex={0} aria-label={`Open ${deck.name} ${angle} camera`} onClick={(event) => { event.stopPropagation(); onCameraChange({ deckId: deck.id, angle }); }} onKeyDown={(event) => { if (event.key !== 'Enter' && event.key !== ' ') return; event.preventDefault(); event.stopPropagation(); onCameraChange({ deckId: deck.id, angle }); }}><circle r="10" /><Camera x={-6} y={-6} size={12} /><text y="20" textAnchor="middle">{angle}</text></g>; })}
                      </g>
                    );
                  })}

                  {chargers.map((charger) => {
                    const reading = evReadings.find((candidate) => candidate.chargerId === charger.id);
                    if (!reading) return null;
                    const point = projectGeo2d(campus, charger.geo);
                    return <g key={charger.id} className={focus?.kind === 'ev' && focus.id === charger.id ? 'ps-ev-marker ps-ev-marker--selected' : 'ps-ev-marker'} role="button" tabIndex={0} aria-label={`${charger.name}, ${reading.free} of ${reading.ports} ports free`} transform={`translate(${point.x} ${point.y})`} onClick={() => onFocusChange({ kind: 'ev', id: charger.id })} onKeyDown={(event) => { if (event.key !== 'Enter' && event.key !== ' ') return; event.preventDefault(); onFocusChange({ kind: 'ev', id: charger.id }); }}><circle r="9" className={reading.free ? 'ps-ev-dot ps-ev-dot--free' : 'ps-ev-dot'} /><BatteryCharging x={-5} y={-5} size={10} /></g>;
                  })}
                  <g className="ps-arrival-marker" transform={`translate(${arrivalPoint2d.x} ${arrivalPoint2d.y})`}><circle r="11" /><Navigation size={14} x={-7} y={-7} /></g>
                </svg>
              ) : (
                <svg className="ps-campus-map ps-campus-map--3d" viewBox="0 0 1000 600" role="img" aria-label={`${campus.name} three-dimensional campus map`}>
                  <defs><pattern id={`ps-grid-${campus.id}`} width="32" height="32" patternUnits="userSpaceOnUse"><path d="M 32 0 L 0 0 0 32" fill="none" stroke="currentColor" strokeWidth="1" opacity=".16" /></pattern></defs>
                  <rect className="ps-map-ground" width="1000" height="600" rx="18" /><rect className="ps-map-grid" width="1000" height="600" rx="18" fill={`url(#ps-grid-${campus.id})`} /><path className="ps-map-road" d="M40 340 C190 270 330 375 510 310 S790 220 960 292" /><path className="ps-map-road ps-map-road--thin" d="M175 28 C245 170 224 390 170 570" /><path className="ps-map-route" d={routePath(arrivalPoint3d, targetPoint3d)} />
                  {campus.places.map((place) => { const point = projectGeo(campus, place.geo); const footprint = projectFootprint(place.footprint); const selected = place.id === target.id; return <g key={place.id} className={`ps-map-building ${selected ? 'ps-map-building--target' : ''}`} transform={`translate(${point.x} ${point.y})`}><polygon className="ps-map-building__side" points={`${-footprint.width / 2},${-footprint.depth / 2} ${footprint.width / 2},${-footprint.depth / 2} ${footprint.width / 2},${footprint.depth / 2} ${-footprint.width / 2},${footprint.depth / 2}`} transform={`translate(0 ${footprint.height})`} /><rect className="ps-map-building__face" x={-footprint.width / 2} y={-footprint.depth / 2 - footprint.height} width={footprint.width} height={footprint.depth} rx="4" /><text className="ps-map-label" y={footprint.depth / 2 + 19} textAnchor="middle">{place.short}</text></g>; })}
                  {campus.decks.map((deck) => { const point = projectGeo(campus, deck.geo); const footprint = projectFootprint(deck.footprint); const reading = readings.find((candidate) => candidate.deckId === deck.id); if (!reading) return null; return <g key={deck.id} className={focus?.kind === 'deck' && focus.id === deck.id ? 'ps-parking-structure ps-parking-structure--highlighted' : 'ps-parking-structure'} role="button" tabIndex={0} onClick={() => onFocusChange({ kind: 'deck', id: deck.id })} onKeyDown={(event) => { if (event.key !== 'Enter' && event.key !== ' ') return; event.preventDefault(); onFocusChange({ kind: 'deck', id: deck.id }); }}>{deck.kind === 'lot' ? <g className="ps-surface-lot"><rect x={point.x - footprint.width / 2} y={point.y - footprint.depth / 2} width={footprint.width} height={footprint.depth} rx="5" />{parkingBayCells(deck, reading, point).map((bay) => <rect key={bay.id} className={bay.open ? 'ps-parking-bay ps-parking-bay--open' : 'ps-parking-bay ps-parking-bay--occupied'} x={bay.x} y={bay.y} width={bay.width} height={bay.height} rx="1" />)}<text className="ps-garage-count" x={point.x} y={point.y + footprint.depth / 2 + 17} textAnchor="middle">{deck.name} · {reading.open} open</text></g> : <g className="ps-stacked-garage" transform={`translate(${point.x} ${point.y})`}>{sequence(deck.levels).map((levelIndex) => <rect key={`${deck.id}-${levelIndex}`} x={-footprint.width / 2} y={-footprint.depth / 2 - levelIndex * 6} width={footprint.width} height={footprint.depth} rx="4" />)}<rect className="ps-garage-face" x={-footprint.width / 2} y={-footprint.depth / 2 - (deck.levels - 1) * 6} width={footprint.width} height={footprint.depth} rx="4" /><text className="ps-garage-count" y="4" textAnchor="middle">{deck.short} · {reading.open} open</text></g>}{CAMERA_ANGLES.map((angle) => { const pin = cameraPinPoint(point, angle); return <g key={`${deck.id}-${angle}`} className="ps-camera-pin" transform={`translate(${pin.x} ${pin.y})`} role="button" tabIndex={0} aria-label={`Open ${deck.name} ${angle} camera`} onClick={(event) => { event.stopPropagation(); onCameraChange({ deckId: deck.id, angle }); }} onKeyDown={(event) => { if (event.key !== 'Enter' && event.key !== ' ') return; event.preventDefault(); event.stopPropagation(); onCameraChange({ deckId: deck.id, angle }); }}><circle r="10" /><Camera x={-6} y={-6} size={12} /><text y="20" textAnchor="middle">{angle}</text></g>; })}</g>; })}
                  <g className="ps-arrival-marker" transform={`translate(${arrivalPoint3d.x} ${arrivalPoint3d.y})`}><circle r="11" /><Navigation size={14} x={-7} y={-7} /></g>
                </svg>
              )}
            </div>
            <div className="ps-map-caption"><span><i className="ps-map-key ps-map-key--gold" /> Active class</span><span><i className="ps-map-key ps-map-key--open" /> Open · SIM</span><span><i className="ps-map-key ps-map-key--full" /> Occupied · SIM</span><span><BatteryCharging size={12} /> EV ports · SIM</span><span>Schematic · positions © OpenStreetMap contributors · counts SIM</span></div>
          </div>

          <aside className="ps-map-side" aria-live="polite">
            {mapInfo ? (
              <article className="ps-map-info-card">
                <button type="button" aria-label="Close map information" onClick={() => onFocusChange(null)}><X size={15} /></button>
                <span>{mapInfo.kind === 'ev' ? <BatteryCharging size={19} /> : mapInfo.kind === 'spot' ? <MapPin size={19} /> : <Building2 size={19} />}</span>
                <small>{mapInfo.kind.toUpperCase()} INFORMATION</small>
                <h2>{mapInfo.title}</h2><p>{mapInfo.detail}</p>
                <div>{mapInfo.lines.map((line) => <span key={line}>{line}</span>)}</div>
                <p>{mapInfo.walkMin} min walk to {target.short}</p>
                {mapInfo.approx && <em>Location approximate (SIM)</em>}
                <footer><a href={appleDirectionsUrl(mapInfo.geo)} target="_blank" rel="noopener noreferrer">Get Directions ↗</a><a href={googleDirectionsUrl(mapInfo.geo)} target="_blank" rel="noopener noreferrer">Google Maps ↗</a></footer>
              </article>
            ) : (
              <div className="ps-map-side-default"><ScanLine size={28} /><h2>Select a parking feature</h2><p>Choose a white spot, garage name, or EV charger for counts, walking time, and directions.</p><div>{campus.decks.map((deck) => { const reading = readings.find((candidate) => candidate.deckId === deck.id); return reading ? <button type="button" key={deck.id} onClick={() => onFocusChange({ kind: 'deck', id: deck.id })}><span><strong>{deck.short}</strong><small>{reading.open} open · SIM</small></span><StatusBadge status={reading.status} occupancy={reading.occupancy} /></button> : null; })}</div></div>
            )}
            {focus?.kind === 'deck' && cvOverrides[focus.id] && <button className="ps-map-clear-cv" type="button" onClick={() => onClearCvOverride(focus.id)}><RotateCcw size={13} /> Clear all CV overrides</button>}
          </aside>
        </div>
      )}
    </section>
  );
}
