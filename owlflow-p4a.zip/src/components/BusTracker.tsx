import { useEffect, useMemo, useRef, useState } from 'react';
import { BusFront, Clock3, MapPin, Navigation, UsersRound } from 'lucide-react';
import { BUS_ROUTES, getBusRoute } from '../data/busRoutes';
import { busPoint, busTelemetry, routePolyline } from '../engine/bus';
import { useNowSeconds } from '../hooks/useNowSeconds';
import type { CampusId, Scenario } from '../types';

interface BusTrackerProps {
  scenario: Scenario;
  campusId: CampusId;
  minute: number;
}

export function BusTracker({ scenario, campusId, minute }: BusTrackerProps) {
  const firstRoute = getBusRoute();
  const [selectedRouteId, setSelectedRouteId] = useState(firstRoute.id);
  const [selectedBusId, setSelectedBusId] = useState<string | null>(null);
  const busRefs = useRef<Record<string, SVGGElement | null>>({});
  const animationRef = useRef<number | null>(null);
  const nowSeconds = useNowSeconds();
  const selectedRoute = BUS_ROUTES.find((route) => route.id === selectedRouteId) ?? firstRoute;
  const selectedBus = BUS_ROUTES.flatMap((route) => route.buses.map((bus) => ({ route, bus }))).find((item) => item.bus.id === selectedBusId);
  const telemetry = useMemo(
    () => selectedBus ? busTelemetry(selectedBus.route, selectedBus.bus, scenario, nowSeconds, campusId, minute) : null,
    [campusId, minute, nowSeconds, scenario, selectedBus],
  );

  useEffect(() => {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let lastPaint = Number.NEGATIVE_INFINITY;
    const update = (elapsedMs: number) => {
      if (!reducedMotion && elapsedMs - lastPaint < 100) {
        animationRef.current = window.requestAnimationFrame(update);
        return;
      }
      lastPaint = elapsedMs;
      for (const route of BUS_ROUTES) {
        for (const bus of route.buses) {
          const element = busRefs.current[bus.id];
          if (!element) continue;
          const point = busPoint(route, bus, reducedMotion ? 0 : elapsedMs);
          element.setAttribute('transform', `translate(${point.x} ${point.y}) rotate(${point.angle})`);
        }
      }
      if (!reducedMotion) animationRef.current = window.requestAnimationFrame(update);
    };
    animationRef.current = window.requestAnimationFrame(update);
    return () => {
      if (animationRef.current !== null) window.cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    };
  }, []);

  return (
    <section className="ps-bus-tracker" aria-labelledby="ps-bus-title">
      <div className="ps-bus-toolbar">
        <div><span><BusFront size={20} /></span><div><small>SIMULATED TRANSIT NETWORK</small><h2 id="ps-bus-title">Live Big Owl Bus Tracker</h2></div></div>
        <p>Passio GO!-inspired demo · no live API calls</p>
      </div>

      <div className="ps-bus-route-tabs" role="group" aria-label="Bus route">
        {BUS_ROUTES.map((route) => (
          <button
            type="button"
            key={route.id}
            aria-pressed={route.id === selectedRoute.id}
            onClick={() => {
              setSelectedRouteId(route.id);
              setSelectedBusId(null);
            }}
          >
            <i style={{ background: route.color }} />
            <span><strong>{route.name}</strong><small>Every {route.headwayMin} min</small></span>
          </button>
        ))}
      </div>

      <div className="ps-bus-vehicle-picker" role="group" aria-label={`${selectedRoute.name} buses`}>
        <span>Vehicles on route</span>
        {selectedRoute.buses.map((bus) => (
          <button
            type="button"
            key={bus.id}
            aria-pressed={bus.id === selectedBusId}
            onClick={() => setSelectedBusId(bus.id)}
          >
            <BusFront size={14} /> {bus.label}
          </button>
        ))}
      </div>

      <div className="ps-bus-layout">
        <div className="ps-bus-map-shell">
          <svg viewBox="0 0 1000 560" role="img" aria-label="Animated simulated Big Owl Bus routes">
            <rect width="1000" height="560" rx="18" className="ps-bus-ground" />
            <path d="M25 275 C180 230 315 305 470 270 S770 170 975 225" className="ps-bus-road" />
            <path d="M460 20 C415 175 480 375 535 540" className="ps-bus-road ps-bus-road--thin" />
            <text x="92" y="42" className="ps-bus-campus-label">KENNESAW CAMPUS</text>
            <text x="760" y="548" className="ps-bus-campus-label">MARIETTA CAMPUS</text>
            {BUS_ROUTES.map((route) => (
              <g key={route.id} className={route.id === selectedRoute.id ? 'ps-bus-route ps-bus-route--selected' : 'ps-bus-route'}>
                <polyline points={routePolyline(route)} fill="none" stroke={route.color} />
                {route.stops.map((stop) => (
                  <g key={stop.id} transform={`translate(${stop.x} ${stop.y})`} className="ps-bus-stop">
                    <circle r="8" style={{ stroke: route.color }} />
                    {route.id === selectedRoute.id && <text y="-14" textAnchor="middle">{stop.name}</text>}
                  </g>
                ))}
                {route.buses.map((bus) => (
                  <g
                    key={bus.id}
                    ref={(element) => { busRefs.current[bus.id] = element; }}
                    className={bus.id === selectedBusId ? 'ps-bus-marker ps-bus-marker--selected' : 'ps-bus-marker'}
                    role="button"
                    tabIndex={0}
                    aria-label={`${bus.label} on ${route.name}`}
                    onClick={() => {
                      setSelectedRouteId(route.id);
                      setSelectedBusId(bus.id);
                    }}
                    onKeyDown={(event) => {
                      if (event.key !== 'Enter' && event.key !== ' ') return;
                      event.preventDefault();
                      setSelectedRouteId(route.id);
                      setSelectedBusId(bus.id);
                    }}
                  >
                    <rect x="-18" y="-11" width="36" height="22" rx="6" style={{ fill: route.color }} />
                    <path d="M-10-4h20v8h-20z" fill="#0B0B0D" opacity=".8" />
                    <circle cx="-10" cy="12" r="4" fill="#F8FAFC" />
                    <circle cx="10" cy="12" r="4" fill="#F8FAFC" />
                  </g>
                ))}
              </g>
            ))}
          </svg>
          <div className="ps-bus-map-legend"><span><i /> Animated bus</span><span><i /> Selected route</span><span>SIM · no passenger location data</span></div>
        </div>

        <aside className="ps-bus-detail">
          {selectedBus && telemetry ? (
            <>
              <span className="ps-bus-detail__label">SELECTED VEHICLE</span>
              <h3>{selectedBus.bus.label}</h3>
              <p>{selectedBus.route.name}</p>
              <div className="ps-bus-load">
                <UsersRound size={18} />
                <span><strong>{telemetry.loadPct}% passenger load</strong><small>{telemetry.loadPct > 90 ? 'Full' : telemetry.loadPct > 70 ? 'Busy' : 'Seats likely available'} · SIM</small></span>
              </div>
              <dl>
                <div><dt><Navigation size={15} /> Status</dt><dd>{telemetry.delayMin ? `+${telemetry.delayMin} min` : 'On time'}</dd></div>
                <div><dt><MapPin size={15} /> Next stop</dt><dd>{telemetry.nextStop}</dd></div>
                <div><dt><Clock3 size={15} /> ETA</dt><dd>{telemetry.etaMin} min</dd></div>
              </dl>
            </>
          ) : (
            <div className="ps-bus-detail__empty"><BusFront size={37} /><h3>Choose a moving bus</h3><p>Open its route, passenger load, delay status, next stop, and ETA.</p></div>
          )}
          <div className="ps-route-stops">
            <span>Route stops</span>
            {selectedRoute.stops.map((stop, index) => <p key={stop.id}><i>{index + 1}</i>{stop.name}</p>)}
          </div>
        </aside>
      </div>
    </section>
  );
}
