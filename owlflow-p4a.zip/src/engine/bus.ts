import { busLoadForScenario } from './intel';
import { seeded } from './random';
import type {
  BusTelemetry,
  BusTrackerRoute,
  BusTrackerVehicle,
  CampusId,
  Scenario,
} from '../types';

export interface BusPoint {
  x: number;
  y: number;
  angle: number;
}

function routePhase(bus: BusTrackerVehicle, elapsedMs: number): number {
  const phase = seeded(`${bus.id}|phase`)();
  return (phase + elapsedMs * bus.speed) % 1;
}

export function pointAlongRoute(route: BusTrackerRoute, progress: number): BusPoint {
  const points = route.path;
  const first = points[0];
  if (!first) return { x: 0, y: 0, angle: 0 };
  if (points.length === 1) return { x: first.x, y: first.y, angle: 0 };
  const segments = points.slice(1).map((point, index) => {
    const start = points[index] ?? first;
    const length = Math.hypot(point.x - start.x, point.y - start.y);
    return { start, end: point, length };
  });
  const totalLength = segments.reduce((sum, segment) => sum + segment.length, 0);
  let target = Math.max(0, Math.min(1, progress)) * totalLength;
  for (const segment of segments) {
    if (target <= segment.length) {
      const ratio = segment.length ? target / segment.length : 0;
      return {
        x: segment.start.x + (segment.end.x - segment.start.x) * ratio,
        y: segment.start.y + (segment.end.y - segment.start.y) * ratio,
        angle: Math.atan2(segment.end.y - segment.start.y, segment.end.x - segment.start.x) * 180 / Math.PI,
      };
    }
    target -= segment.length;
  }
  const last = points[points.length - 1] ?? first;
  return { x: last.x, y: last.y, angle: 0 };
}

export function busPoint(
  route: BusTrackerRoute,
  bus: BusTrackerVehicle,
  elapsedMs: number,
): BusPoint {
  return pointAlongRoute(route, routePhase(bus, elapsedMs));
}

export function routePolyline(route: BusTrackerRoute): string {
  return route.path.map((point) => `${point.x},${point.y}`).join(' ');
}

export function busTelemetry(
  route: BusTrackerRoute,
  bus: BusTrackerVehicle,
  scenario: Scenario,
  nowSeconds: number,
  campusId: CampusId,
  minute: number,
): BusTelemetry {
  const random = seeded(`${route.id}|${bus.id}|telemetry|${Math.floor(nowSeconds / 30)}`);
  const loadPct = busLoadForScenario(scenario, campusId, minute);
  const delayMin = scenario.traffic === 'heavy'
    ? Math.max(1, scenario.shuttleDelayMin)
    : scenario.shuttleDelayMin > 3
      ? scenario.shuttleDelayMin
      : 0;
  const stopIndex = Math.min(route.stops.length - 1, Math.floor(random() * route.stops.length));
  const stop = route.stops[stopIndex] ?? route.stops[0];
  return {
    busId: bus.id,
    loadPct,
    delayMin,
    nextStop: stop?.name ?? 'Next campus stop',
    etaMin: Math.max(1, Math.round(route.headwayMin * (0.2 + random() * 0.65) + delayMin)),
  };
}
