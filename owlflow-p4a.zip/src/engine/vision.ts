import { requestGeminiPayload } from './gemini';
import { seeded } from './random';
import type {
  CvOverride,
  DeckReading,
  LevelReading,
  NormalizedBox,
  Scenario,
  VisionBox,
  VisionFeed,
  VisionResult,
} from '../types';

function clamp01(value: number): number {
  return Math.max(0, Math.min(1, value));
}

function finiteNumber(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}

function sampleBox(imageData: ImageData, box: NormalizedBox): { variance: number; edge: number } {
  const startX = Math.max(0, Math.floor(box.x * imageData.width));
  const startY = Math.max(0, Math.floor(box.y * imageData.height));
  const endX = Math.min(imageData.width, Math.ceil((box.x + box.w) * imageData.width));
  const endY = Math.min(imageData.height, Math.ceil((box.y + box.h) * imageData.height));
  const luminance: number[] = [];

  for (let y = startY; y < endY; y += 3) {
    for (let x = startX; x < endX; x += 3) {
      const index = (y * imageData.width + x) * 4;
      const red = imageData.data[index] ?? 0;
      const green = imageData.data[index + 1] ?? 0;
      const blue = imageData.data[index + 2] ?? 0;
      luminance.push(red * 0.2126 + green * 0.7152 + blue * 0.0722);
    }
  }

  if (!luminance.length) return { variance: 0, edge: 0 };
  const mean = luminance.reduce((sum, value) => sum + value, 0) / luminance.length;
  const variance = luminance.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / luminance.length;
  let edge = 0;
  for (let index = 1; index < luminance.length; index += 1) {
    const current = luminance[index];
    const previous = luminance[index - 1];
    if (current === undefined || previous === undefined) continue;
    edge += Math.abs(current - previous);
  }
  return { variance, edge: edge / Math.max(1, luminance.length - 1) };
}

export function analyzeFrameLocal(
  feed: VisionFeed,
  imageData: ImageData,
  seedKey: string,
): VisionResult {
  const random = seeded(`${feed.id}|${seedKey}|vision`);
  const boxes: VisionBox[] = feed.bayGrid.map((box) => {
    const sample = sampleBox(imageData, box);
    const score = sample.variance + sample.edge * 45 + random() * 180;
    return { ...box, state: score > 760 ? 'occupied' : 'open' };
  });
  const open = boxes.filter((box) => box.state === 'open').length;
  return {
    boxes,
    open,
    occupied: boxes.length - open,
    total: boxes.length,
    confidence: 0.78 + random() * 0.16,
    engine: 'local',
  };
}

function geminiText(payload: unknown): string | null {
  if (!payload || typeof payload !== 'object') return null;
  const candidates = Reflect.get(payload, 'candidates');
  if (!Array.isArray(candidates)) return null;
  const first = candidates[0];
  if (!first || typeof first !== 'object') return null;
  const content = Reflect.get(first, 'content');
  if (!content || typeof content !== 'object') return null;
  const parts = Reflect.get(content, 'parts');
  if (!Array.isArray(parts)) return null;
  for (const part of parts) {
    if (!part || typeof part !== 'object') continue;
    const text = Reflect.get(part, 'text');
    if (typeof text === 'string') return text;
  }
  return null;
}

function parsedVisionResult(value: unknown): VisionResult | null {
  if (!value || typeof value !== 'object') return null;
  const rawBoxes = Reflect.get(value, 'boxes');
  const rawConfidence = finiteNumber(Reflect.get(value, 'confidence'));
  if (!Array.isArray(rawBoxes) || rawConfidence === null) return null;
  const boxes: VisionBox[] = [];

  for (const candidate of rawBoxes) {
    if (!candidate || typeof candidate !== 'object') return null;
    const x = finiteNumber(Reflect.get(candidate, 'x'));
    const y = finiteNumber(Reflect.get(candidate, 'y'));
    const w = finiteNumber(Reflect.get(candidate, 'w'));
    const h = finiteNumber(Reflect.get(candidate, 'h'));
    const state = Reflect.get(candidate, 'state');
    if (x === null || y === null || w === null || h === null) return null;
    if (state !== 'open' && state !== 'occupied') return null;
    boxes.push({
      x: clamp01(x),
      y: clamp01(y),
      w: clamp01(w),
      h: clamp01(h),
      state,
    });
  }

  const open = boxes.filter((box) => box.state === 'open').length;
  return {
    boxes,
    open,
    occupied: boxes.length - open,
    total: boxes.length,
    confidence: clamp01(rawConfidence),
    engine: 'gemini',
  };
}

export async function analyzeFrameGemini(
  frameJpegBase64: string,
  feed: VisionFeed,
  signal?: AbortSignal,
): Promise<VisionResult> {
  const reply = await requestGeminiPayload(
    {
      contents: [
        {
          role: 'user',
          parts: [
            {
              inline_data: {
                mime_type: 'image/jpeg',
                data: frameJpegBase64,
              },
            },
            {
              text: `Analyze this parking frame for ${feed.label}. Return normalized boxes for visible parking bays and classify each as open or occupied. Coordinates must be between 0 and 1.`,
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0,
        responseMimeType: 'application/json',
        responseJsonSchema: {
          type: 'object',
          properties: {
            boxes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  x: { type: 'number' },
                  y: { type: 'number' },
                  w: { type: 'number' },
                  h: { type: 'number' },
                  state: { type: 'string', enum: ['open', 'occupied'] },
                },
                required: ['x', 'y', 'w', 'h', 'state'],
              },
            },
            open: { type: 'integer' },
            occupied: { type: 'integer' },
            total: { type: 'integer' },
            confidence: { type: 'number' },
          },
          required: ['boxes', 'open', 'occupied', 'total', 'confidence'],
        },
      },
    },
    signal,
  );
  const text = geminiText(reply.payload);
  if (!text) throw new Error(`${reply.model} returned no vision JSON.`);
  let parsed: unknown;
  try {
    parsed = JSON.parse(text) as unknown;
  } catch {
    throw new Error(`${reply.model} returned invalid vision JSON.`);
  }
  const result = parsedVisionResult(parsed);
  if (!result) throw new Error(`${reply.model} returned an invalid vision result.`);
  return result;
}

export function reconcileVisionWithReading(
  result: VisionResult,
  level: LevelReading,
  seedKey: string,
): VisionResult {
  const openRatio = level.capacity > 0 ? level.open / level.capacity : 0;
  const desiredOpenBoxes = Math.round(result.boxes.length * openRatio);
  const random = seeded(`${seedKey}|reconcile`);
  const ranked = result.boxes
    .map((box, index) => ({ box, index, rank: random() }))
    .sort((a, b) => a.rank - b.rank);
  const openIndexes = new Set(ranked.slice(0, desiredOpenBoxes).map((item) => item.index));
  const boxes = result.boxes.map((box, index) => ({
    ...box,
    state: openIndexes.has(index) ? 'open' as const : 'occupied' as const,
  }));
  return {
    boxes,
    open: level.open,
    occupied: Math.max(0, level.capacity - level.open),
    total: level.capacity,
    confidence: 0.9 + seeded(`${seedKey}|confidence`)() * 0.08,
    engine: result.engine,
  };
}

export function simulateVisionFeed(
  feed: VisionFeed,
  level: LevelReading,
  scenario: Scenario,
  minute: number,
): VisionResult {
  const seedKey = `${feed.deckId}|${feed.angle}|${scenario.id}|${Math.floor(minute / 15)}`;
  const random = seeded(seedKey);
  const openInView = Math.round(feed.bayGrid.length * (level.open / Math.max(1, level.capacity)));
  const ranked = feed.bayGrid
    .map((box, index) => ({ box, index, rank: random() }))
    .sort((a, b) => a.rank - b.rank);
  const openIndexes = new Set(ranked.slice(0, openInView).map((item) => item.index));
  const boxes = feed.bayGrid.map((box, index) => ({
    ...box,
    state: openIndexes.has(index) ? 'open' as const : 'occupied' as const,
  }));
  return {
    boxes,
    open: openInView,
    occupied: boxes.length - openInView,
    total: boxes.length,
    confidence: 0.91 + random() * 0.07,
    engine: 'local',
  };
}

export function scaleVisionToCapacity(
  result: VisionResult,
  capacity: number,
): VisionResult {
  const ratio = result.total > 0 ? result.open / result.total : 0;
  const open = Math.round(capacity * ratio);
  return {
    ...result,
    open,
    occupied: capacity - open,
    total: capacity,
  };
}

export function createCvOverride(result: VisionResult): CvOverride {
  return {
    open: result.open,
    total: result.total,
    source: 'cv',
    atMs: Date.now(),
  };
}

export function simulatedCarColor(
  feed: VisionFeed,
  index: number,
  scenario: Scenario,
  minute: number,
): string {
  const colors = ['#64748B', '#A3A8B3', '#7F1D1D', '#1E3A8A', '#3F3F46'] as const;
  const random = seeded(`${feed.deckId}|${feed.angle}|${scenario.id}|${Math.floor(minute / 15)}|car|${index}`);
  return colors[Math.floor(random() * colors.length)] ?? colors[0];
}

export function getVisionLevel(
  readings: readonly DeckReading[],
  deckId: string,
  levelNumber: number,
): LevelReading {
  const reading = readings.find((candidate) => candidate.deckId === deckId);
  const level = reading?.levels.find((candidate) => candidate.level === levelNumber);
  if (!level) throw new Error(`Missing level ${levelNumber} reading for ${deckId}.`);
  return level;
}
