import type { CampusId, DiningHall } from '../types';

export const DINING_HALLS: readonly DiningHall[] = [
  {
    id: 'k-commons',
    campusId: 'kennesaw',
    placeId: 'k-commons',
    name: 'The Commons',
    short: 'Commons',
    geo: { lat: 34.039901, lng: -84.5818194 },
    stations: [
      {
        id: 'k-plant-forward',
        name: 'Plant Forward',
        tags: ['vegetarian', 'vegan', 'gluten-free'],
        baseQueue: 3,
        perMin: 8,
        menuItems: [
          { name: 'Roasted Vegetable Grain Bowl', station: 'Plant Forward', calories: 510, tags: ['vegetarian', 'vegan'] },
          { name: 'Chickpea Curry with Rice', station: 'Plant Forward', calories: 470, tags: ['vegetarian', 'vegan', 'gluten-free'] },
          { name: 'Garden Power Salad', station: 'Plant Forward', calories: 330, tags: ['vegetarian', 'vegan', 'gluten-free'] },
        ],
      },
      {
        id: 'k-halal-grill',
        name: 'Halal Grill',
        tags: ['halal'],
        baseQueue: 5,
        perMin: 10,
        menuItems: [
          { name: 'Halal Chicken Rice Plate', station: 'Halal Grill', calories: 640, tags: ['halal', 'gluten-free'] },
          { name: 'Beef Kofta Pita', station: 'Halal Grill', calories: 590, tags: ['halal'] },
          { name: 'Falafel Mezze Plate', station: 'Halal Grill', calories: 520, tags: ['halal', 'vegetarian', 'vegan'] },
        ],
      },
      {
        id: 'k-homestyle',
        name: 'Homestyle',
        tags: ['vegetarian', 'gluten-free'],
        baseQueue: 4,
        perMin: 9,
        menuItems: [
          { name: 'Herb Roasted Chicken', station: 'Homestyle', calories: 560, tags: ['gluten-free'] },
          { name: 'Macaroni and Cheese', station: 'Homestyle', calories: 490, tags: ['vegetarian'] },
          { name: 'Green Beans and Potatoes', station: 'Homestyle', calories: 230, tags: ['vegetarian', 'vegan', 'gluten-free'] },
        ],
      },
      {
        id: 'k-pizza-pasta',
        name: 'Pizza & Pasta',
        tags: ['vegetarian'],
        baseQueue: 4,
        perMin: 7,
        menuItems: [
          { name: 'Margherita Pizza', station: 'Pizza & Pasta', calories: 610, tags: ['vegetarian'] },
          { name: 'Penne Marinara', station: 'Pizza & Pasta', calories: 540, tags: ['vegetarian', 'vegan'] },
          { name: 'Chicken Alfredo', station: 'Pizza & Pasta', calories: 760, tags: [] },
        ],
      },
    ],
  },
  {
    id: 'm-stingers',
    campusId: 'marietta',
    placeId: 'm-stingers',
    name: 'Stingers',
    short: 'Stingers',
    geo: { lat: 33.9373825, lng: -84.5222994 },
    stations: [
      {
        id: 'm-grab-go',
        name: 'Grab & Go Market',
        tags: ['vegetarian', 'vegan', 'halal', 'gluten-free'],
        baseQueue: 1,
        perMin: 4,
        menuItems: [
          { name: 'Hummus Snack Box', station: 'Grab & Go Market', calories: 390, tags: ['vegetarian', 'vegan', 'halal'] },
          { name: 'Chicken Caesar Wrap', station: 'Grab & Go Market', calories: 520, tags: [] },
          { name: 'Fruit and Yogurt Cup', station: 'Grab & Go Market', calories: 280, tags: ['vegetarian', 'gluten-free'] },
        ],
      },
      {
        id: 'm-grill',
        name: 'Grill',
        tags: ['vegetarian', 'halal', 'gluten-free'],
        baseQueue: 4,
        perMin: 9,
        menuItems: [
          { name: 'Black Bean Burger', station: 'Grill', calories: 550, tags: ['vegetarian', 'vegan'] },
          { name: 'Halal Grilled Chicken Sandwich', station: 'Grill', calories: 620, tags: ['halal'] },
          { name: 'Grilled Chicken Power Bowl', station: 'Grill', calories: 510, tags: ['gluten-free'] },
        ],
      },
      {
        id: 'm-deli',
        name: 'Deli',
        tags: ['vegetarian', 'halal', 'gluten-free'],
        baseQueue: 3,
        perMin: 7,
        menuItems: [
          { name: 'Turkey Avocado Sub', station: 'Deli', calories: 610, tags: [] },
          { name: 'Caprese Sandwich', station: 'Deli', calories: 530, tags: ['vegetarian'] },
          { name: 'Build-Your-Own Salad', station: 'Deli', calories: 360, tags: ['vegetarian', 'vegan', 'halal', 'gluten-free'] },
        ],
      },
    ],
  },
];

export function getDiningHall(campusId: CampusId): DiningHall {
  const hall = DINING_HALLS.find((candidate) => candidate.campusId === campusId);
  if (!hall) throw new Error(`No dining hall configured for ${campusId}.`);
  return hall;
}
