import { useMemo } from 'react';
import { Check, Clock3, Flame, Leaf, Sparkles, Utensils } from 'lucide-react';
import { menuMatches, readDiningHall } from '../engine/dining';
import type {
  DietaryTag,
  DiningHall,
  PitStopPlan,
  Scenario,
} from '../types';

interface DiningMenuProps {
  hall: DiningHall;
  scenario: Scenario;
  minute: number;
  selectedTags: DietaryTag[];
  pitStop?: PitStopPlan;
  onTagsChange: (tags: DietaryTag[]) => void;
}

export function DiningMenu({
  hall,
  scenario,
  minute,
  selectedTags,
  pitStop,
  onTagsChange,
}: DiningMenuProps) {
  const readings = useMemo(
    () => readDiningHall(hall, minute, scenario),
    [hall, minute, scenario],
  );

  return (
    <section className="ps-dining" aria-labelledby="ps-dining-title">
      <div className="ps-tab-hero">
        <div>
          <p className="ps-kicker">Dining queue + menu engine</p>
          <h1 id="ps-dining-title">Eat for the schedule, not the line.</h1>
          <p>OwlFlow ranks today&apos;s stations by simulated queue, crowd load, dietary fit, and the walk to your next class.</p>
        </div>
        <div className="ps-dining-hall-badge"><Utensils size={23} /><span><small>Active dining hall</small><strong>{hall.name}</strong></span></div>
      </div>

      <div className="ps-dietary-filter">
        <span><Leaf size={16} /> Dietary filters</span>
        <div role="group" aria-label="Dietary filters">
          {(['vegetarian', 'vegan', 'halal', 'gluten-free'] as const).map((tag) => {
            const selected = selectedTags.includes(tag);
            return (
              <button
                type="button"
                key={tag}
                aria-pressed={selected}
                onClick={() => onTagsChange(selected ? selectedTags.filter((candidate) => candidate !== tag) : [...selectedTags, tag])}
              >
                {selected && <Check size={13} />}{tag}
              </button>
            );
          })}
        </div>
      </div>

      {pitStop && (
        <article className="ps-meal-pick">
          <span className="ps-meal-pick__icon"><Sparkles size={22} /></span>
          <div><small>AI PIT STOP</small><h2>{pitStop.menuItem.name}</h2><p>{pitStop.stationName} · {pitStop.queueMin} min queue · {pitStop.menuItem.calories} calories</p></div>
          <span className={pitStop.fitsBeforeClass ? 'ps-fit-chip' : 'ps-fit-chip ps-fit-chip--warn'}>{pitStop.fitsBeforeClass ? 'Fits before class' : 'Tight before class'}</span>
        </article>
      )}

      <div className="ps-station-grid">
        {hall.stations.map((station) => {
          const reading = readings.find((candidate) => candidate.stationId === station.id);
          const items = station.menuItems.filter((item) => menuMatches(item, selectedTags));
          return (
            <article className="ps-station-card" key={station.id}>
              <div className="ps-station-card__head">
                <div><small>LIVE QUEUE · SIM</small><h2>{station.name}</h2></div>
                <span className="ps-wait-badge"><Clock3 size={14} /> {reading?.queueMin ?? 0} min</span>
              </div>
              <div className="ps-crowd-meter">
                <span><strong>Crowd load</strong><small>{reading?.crowdPct ?? 0}%</small></span>
                <i><b style={{ width: `${reading?.crowdPct ?? 0}%` }} /></i>
              </div>
              <div className="ps-menu-list">
                <span>Today&apos;s menu</span>
                {items.length ? items.map((item) => (
                  <div key={item.name}>
                    <span><strong>{item.name}</strong><small>{item.tags.length ? item.tags.join(' · ') : 'standard menu'}</small></span>
                    <span><Flame size={13} /> {item.calories}</span>
                  </div>
                )) : (
                  <p>No item at this station matches every selected filter.</p>
                )}
              </div>
            </article>
          );
        })}
      </div>
      <p className="ps-sim-disclosure">Menus are representative demo data. Verify ingredients and allergen handling with KSU Dining before eating.</p>
    </section>
  );
}
