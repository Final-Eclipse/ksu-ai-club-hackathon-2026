# ParkSync · KSU Campus Mobility

**ParkSync** is an AI-powered campus mobility and student flow engine for Kennesaw State University. It compares Drive + Park, Uber campus drop-off, and Big Owl Bus against the student's next class, then flips to the safest eligible fallback when decks fill or rain and traffic surge.

This is a deterministic hackathon simulation for the live demo on Friday, November 20, 2026. It is not an official KSU, Uber, or Big Owl Bus service.

## Run locally

Requirements: Node.js 20.19 or newer. Node.js 22 is recommended.

```bash
npm install
npm run dev
```

Create the production build:

```bash
npm run build
```

No API keys are required. The rendered application makes no API or CDN request on load.

## Live demo path

The sticky **LIVE DEMO** bar provides three deterministic scenarios:

| Scenario | AI decision for `k-bio` | Key evidence |
|---|---|---|
| Normal Morning | Drive + Park | West Deck, about 31 minutes, Filling at about 93% |
| Decks Hit 98% Full | Uber Campus Drop-Off | About 28 minutes, $24–29 simulated fare, Campus Loop curb |
| Rain & Traffic Surge | Big Owl Bus | About 54 minutes, $0 |

Suggested sequence:

1. Begin with `BIOL · MWF · Science` at 11:15 AM.
2. Show the normal West Deck recommendation and explainable camera reading.
3. Select **Decks Hit 98% Full** and show all decks turn Full, Drive become ineligible, and Uber become the AI pick.
4. Open the real Uber mobile-web deep link.
5. Select **Rain & Traffic Surge** and show Big Owl Bus win at $0.
6. Switch to Marietta. ParkSync loads `ENGR · MW · Atrium + ETC`, includes Central Lot as a one-level lot, and produces the same three-way scenario flip.
7. Finish with the 2.5D campus view and seeded bay-level sensor grid.

## Architecture

```text
src/
├── components/
│   ├── CampusMap.tsx
│   ├── CommunityReports.tsx
│   ├── DemoBar.tsx
│   ├── Planner.tsx
│   ├── RecommendationList.tsx
│   ├── ScheduleImporter.tsx
│   └── StatusBadge.tsx
├── data/
│   ├── campuses.ts
│   ├── presets.ts
│   └── scenarios.ts
├── engine/
│   ├── commute.ts
│   ├── forecast.ts
│   ├── geo.ts
│   ├── mapLayout.ts
│   ├── random.ts
│   ├── schedule.ts
│   └── time.ts
├── state/
│   └── plan.ts
├── types/
│   └── index.ts
└── App.tsx
```

## Decision engine

ParkSync uses a pure TypeScript pipeline:

1. Predict deck occupancy from the deck prior, a Gaussian 11:30 AM peak, and the selected scenario.
2. Generate deterministic level and bay readings with seeded FNV-1a + Mulberry32 pseudo-random values.
3. Calculate geographic walking time with the haversine distance.
4. Build Drive, Uber, and Big Owl Bus journeys from individual legs.
5. Score journey time, rideshare fare, and late-arrival risk.
6. Disqualify Drive when its selected deck exceeds 95% occupancy or when rain/heavy traffic activates the fallback rule.
7. Return exactly one short explanation sentence with the winning evidence.

Simulation values never use `Math.random()`, `Date.now()`, or the current clock. The same preset and scenario always produce the same result.

## Uber deep link

The selected curb pin creates a mobile Uber URL in this shape:

```text
https://m.uber.com/ul/?action=setPickup&pickup=my_location&dropoff[latitude]=...
```

Only parameter values are encoded. The bracketed Uber parameter names remain intact.

## Data boundaries

- Campus coordinates are the OpenStreetMap coordinates supplied for this hackathon build.
- Locations marked `≈` use an estimated coordinate and carry `geoApprox: true` in the data.
- Deck capacities, camera confidence, occupancy, bay availability, shuttle load, fares, and scenario conditions are clearly labeled simulations.
- ParkSync does not claim access to KSU cameras or live parking telemetry.
- The application does not collect identity, license-plate, or location-history data.

## Compatibility retained for later prompts

The shared type module retains the original OwlPark interfaces. `campuses.ts`, `forecast.ts`, and `schedule.ts` keep compatibility exports used by the original scanner, guide, sharing, and parser utilities while exposing the new ParkSync contracts.

## Validation

```bash
npm run check
npm run build
```

There is currently no lint script in `package.json`.
