export type CampusId = 'kennesaw' | 'marietta';
export type ScenarioId = 'normal' | 'decksFull' | 'rainSurge';
export type CommuteMode = 'drive' | 'uber' | 'shuttle';
export type OccupancyStatus = 'open' | 'filling' | 'full';
export type PlaceKind = 'academic' | 'dining' | 'library' | 'dorm' | 'student-center';

export interface GeoPoint {
  lat: number;
  lng: number;
}

export interface Footprint {
  w: number;
  d: number;
  h: number;
}

export interface Place {
  id: string;
  campusId: CampusId;
  kind: PlaceKind;
  name: string;
  short: string;
  geo: GeoPoint;
  footprint: Footprint;
  aliases: string[];
  geoApprox?: boolean;
}

export interface Deck {
  id: string;
  campusId: CampusId;
  kind: 'deck' | 'lot';
  name: string;
  short: string;
  geo: GeoPoint;
  footprint: Footprint;
  capacity: number;
  levels: number;
  baysPerLevel: number;
  baseOccupancy: number;
  peakBoost: number;
  geoApprox?: boolean;
}

export interface DropOffPin {
  id: string;
  campusId: CampusId;
  name: string;
  address: string;
  geo: GeoPoint;
  congestion: 'low' | 'medium' | 'high';
}

export interface ShuttleRoute {
  id: string;
  campusId: CampusId;
  name: string;
  remoteLot: string;
  headwayMin: number;
  rideMin: number;
  stopName: string;
  stopGeo: GeoPoint;
}

export interface Campus {
  id: CampusId;
  name: string;
  center: GeoPoint;
  places: Place[];
  decks: Deck[];
  pins: DropOffPin[];
  shuttle: ShuttleRoute;
}

export interface ClassSession {
  id: string;
  course: string;
  buildingId: string;
  room: string;
  days: string;
  startMin: number;
  endMin: number;
}

export interface CommuteProfile {
  originLabel: string;
  driveMin: number;
  distanceMi: number;
}

export interface SchedulePreset {
  id: string;
  label: string;
  persona: string;
  campusId: CampusId;
  arrivalMin: number;
  profile: CommuteProfile;
  classes: ClassSession[];
  dormId?: string;
}

export interface Scenario {
  id: ScenarioId;
  label: string;
  occupancyDelta: number;
  occupancyFloor: number | null;
  trafficMult: number;
  walkMult: number;
  uberSurge: number;
  uberExtraWaitMin: number;
  shuttleDelayMin: number;
  shuttleLoadPct: number;
  weather: 'clear' | 'rain';
  traffic: 'normal' | 'heavy';
  crowdMult: number;
}

export interface BayReading {
  id: string;
  label: string;
  capacity: number;
  open: number;
  status: OccupancyStatus;
}

export interface LevelReading {
  level: number;
  capacity: number;
  open: number;
  status: OccupancyStatus;
  bays: BayReading[];
}

export interface DeckReading {
  deckId: string;
  predictedOccupancy: number;
  occupancy: number;
  open: number;
  status: OccupancyStatus;
  levels: LevelReading[];
  bestLevel: number;
  cvConfidence: number;
}

export interface CommuteLeg {
  label: string;
  minutes: number;
}

export interface CommuteOption {
  mode: CommuteMode;
  title: string;
  totalMin: number;
  arriveMin: number;
  slackMin: number;
  legs: CommuteLeg[];
  walkMin: number;
  fareUsd: { low: number; high: number } | null;
  arrivalPoint: { name: string; geo: GeoPoint };
  deck?: { deck: Deck; reading: DeckReading; searchMin: number };
  uber?: { pin: DropOffPin; deepLink: string; waitMin: number };
  shuttle?: { route: ShuttleRoute; waitMin: number; loadPct: number };
  eligible: boolean;
  score: number;
}

export interface CommuteDecision {
  options: CommuteOption[];
  winner: CommuteMode;
  fallback: 'deckFull' | 'weather' | null;
  explanation: string;
  targetName: string;
}

// Compatibility contracts retained for the original OwlPark utility modules.
export type PermitId =
  | 'central'
  | 'east'
  | 'west'
  | 'north'
  | 'south'
  | 'east-economy'
  | 'town-point-economy'
  | 'gutenberg-economy'
  | 'shuttle'
  | 'hourly';
export type Priority = 'balanced' | 'fastest' | 'closest' | 'availability';
export type SemesterPhase = 'normal' | 'opening-weeks' | 'event';
export type MobilityMode = 'standard' | 'step-free';
export type LotKind = 'deck' | 'surface' | 'economy' | 'shuttle' | 'hourly';
export type LotSize = 'small' | 'medium' | 'large';
export type ReportLevel = 'plenty' | 'filling' | 'near-full' | 'full';
export type AvailabilityStatus = 'open' | 'filling' | 'tight' | 'full';
export type ViewId = 'plan' | 'map' | 'reports' | 'schedule' | 'scanner' | 'guide';

export interface MapPoint {
  x: number;
  y: number;
}

export interface BuildingDefinition {
  id: string;
  campusId: CampusId;
  name: string;
  shortName: string;
  aliases: string[];
  point: MapPoint;
  category: 'academic' | 'student-life' | 'library' | 'dining' | 'recreation';
}

export interface ParkingLotDefinition {
  id: string;
  campusId: CampusId;
  name: string;
  shortName: string;
  kind: LotKind;
  size: LotSize;
  point: MapPoint;
  acceptedPermits: PermitId[];
  baseDemand: number;
  covered: boolean;
  evCharging: boolean;
  accessibleSpaces: boolean;
  shuttleMinutes?: number;
  note: string;
}

export interface CampusDefinition {
  id: CampusId;
  name: string;
  shortName: string;
  address: string;
  latitude: number;
  longitude: number;
  officialMapUrl: string;
  buildings: BuildingDefinition[];
  lots: ParkingLotDefinition[];
}

export interface PermitDefinition {
  id: PermitId;
  label: string;
  shortLabel: string;
  description: string;
  color: string;
}

export interface SourceLink {
  label: string;
  detail: string;
  url: string;
}

export interface PlannerState {
  campusId: CampusId;
  destinationId: string;
  permitId: PermitId;
  arrival: string;
  priority: Priority;
  commuteMinutes: number;
  mobilityMode: MobilityMode;
  preferCovered: boolean;
  needsEv: boolean;
  semesterPhase: SemesterPhase;
}

export interface ParkingReport {
  id: string;
  lotId: string;
  level: ReportLevel;
  createdAt: number;
  note?: string;
}

export interface WeatherSnapshot {
  temperatureF: number;
  precipitationProbability: number;
  weatherCode: number;
  condition: string;
  sourceTime: string;
}

export interface LotForecast {
  occupancy: number;
  status: AvailabilityStatus;
  confidence: number;
  activeReportCount: number;
  searchMinutes: number;
  reportSignal?: ReportLevel;
  factors: string[];
}

export interface ParkingRecommendation {
  lot: ParkingLotDefinition;
  forecast: LotForecast;
  walkMinutes: number;
  parkingToDoorMinutes: number;
  totalTripMinutes: number;
  score: number;
  reasons: string[];
  warnings: string[];
}

export interface ClassMeeting {
  id: string;
  name: string;
  campusId: CampusId;
  destinationId: string;
  days: number[];
  startTime: string;
  sourceLine: string;
}

export interface ScheduleParseResult {
  meetings: ClassMeeting[];
  ignoredLines: string[];
}

export type SignVerdict = 'allowed' | 'not-allowed' | 'conditional' | 'unclear';

export interface SignInterpretation {
  verdict: SignVerdict;
  title: string;
  summary: string;
  matchedRules: string[];
  cautions: string[];
}
