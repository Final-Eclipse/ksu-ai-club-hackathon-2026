import { PRESETS } from '../data/presets';
import { pickNextClass } from '../engine/schedule';
import type {
  CampusId,
  ClassSession,
  CommuteMode,
  CommuteProfile,
  ScenarioId,
  SchedulePreset,
} from '../types';

export interface PlanState {
  campusId: CampusId;
  presetId: string | null;
  classes: ClassSession[];
  selectedClassId: string | null;
  arrivalMin: number;
  profile: CommuteProfile;
  scenarioId: ScenarioId;
  selectedMode: CommuteMode | null;
  importNotes: string[];
}

export type PlanAction =
  | { type: 'setCampus'; campusId: CampusId }
  | { type: 'applyPreset'; presetId: string }
  | { type: 'importClasses'; classes: ClassSession[]; notes: string[] }
  | { type: 'selectClass'; classId: string }
  | { type: 'setArrival'; arrivalMin: number }
  | { type: 'setScenario'; scenarioId: ScenarioId }
  | { type: 'selectMode'; mode: CommuteMode | null };

function findPreset(presetId: string): SchedulePreset | undefined {
  return PRESETS.find((preset) => preset.id === presetId);
}

function stateFromPreset(preset: SchedulePreset, scenarioId: ScenarioId): PlanState {
  const classes = preset.classes.map((session) => ({ ...session }));
  const nextClass = pickNextClass(classes, preset.arrivalMin);
  return {
    campusId: preset.campusId,
    presetId: preset.id,
    classes,
    selectedClassId: nextClass?.id ?? null,
    arrivalMin: preset.arrivalMin,
    profile: { ...preset.profile },
    scenarioId,
    selectedMode: null,
    importNotes: [],
  };
}

const initialPreset = findPreset('k-bio');
if (!initialPreset) throw new Error('ParkSync requires the k-bio preset.');

export const INITIAL_PLAN_STATE: PlanState = stateFromPreset(initialPreset, 'normal');

export function planReducer(state: PlanState, action: PlanAction): PlanState {
  switch (action.type) {
    case 'setCampus': {
      const preset = PRESETS.find((candidate) => candidate.campusId === action.campusId);
      return preset ? stateFromPreset(preset, state.scenarioId) : state;
    }
    case 'applyPreset': {
      const preset = findPreset(action.presetId);
      return preset ? stateFromPreset(preset, state.scenarioId) : state;
    }
    case 'importClasses': {
      const nextClass = pickNextClass(action.classes, state.arrivalMin);
      return {
        ...state,
        presetId: null,
        classes: action.classes,
        selectedClassId: nextClass?.id ?? null,
        selectedMode: null,
        importNotes: action.notes,
      };
    }
    case 'selectClass':
      return {
        ...state,
        selectedClassId: action.classId,
        selectedMode: null,
      };
    case 'setArrival':
      return {
        ...state,
        arrivalMin: Math.max(300, Math.min(1320, action.arrivalMin)),
        selectedMode: null,
      };
    case 'setScenario':
      return {
        ...state,
        scenarioId: action.scenarioId,
        selectedMode: null,
      };
    case 'selectMode':
      return {
        ...state,
        selectedMode: action.mode,
      };
    default: {
      const exhaustiveAction: never = action;
      return exhaustiveAction;
    }
  }
}
