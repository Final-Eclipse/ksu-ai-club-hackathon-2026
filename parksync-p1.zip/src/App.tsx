import { useMemo, useReducer } from 'react';
import { Activity, BrainCircuit, GraduationCap, Radio } from 'lucide-react';
import { CampusMap } from './components/CampusMap';
import { CommunityReports } from './components/CommunityReports';
import { DemoBar } from './components/DemoBar';
import { Planner } from './components/Planner';
import { RecommendationList } from './components/RecommendationList';
import { getCampus } from './data/campuses';
import { getScenario } from './data/scenarios';
import { decideCommute } from './engine/commute';
import { readDecks } from './engine/forecast';
import { pickNextClass } from './engine/schedule';
import { INITIAL_PLAN_STATE, planReducer } from './state/plan';

export default function App() {
  const [state, dispatch] = useReducer(planReducer, INITIAL_PLAN_STATE);
  const campus = getCampus(state.campusId);
  const scenario = getScenario(state.scenarioId);
  const nextClass =
    state.classes.find((session) => session.id === state.selectedClassId) ??
    pickNextClass(state.classes, state.arrivalMin);
  const target =
    campus.places.find((place) => place.id === nextClass?.buildingId) ??
    campus.places[0];

  const readings = useMemo(
    () => readDecks(campus, state.arrivalMin, scenario),
    [campus, scenario, state.arrivalMin],
  );
  const decision = useMemo(
    () =>
      decideCommute({
        campus,
        target: { name: target.name, geo: target.geo },
        classStartMin: nextClass?.startMin ?? state.arrivalMin + 60,
        arrivalMin: state.arrivalMin,
        profile: state.profile,
        scenario,
        readings,
      }),
    [campus, nextClass?.startMin, readings, scenario, state.arrivalMin, state.profile, target.geo, target.name],
  );

  return (
    <div className="ps-app">
      <DemoBar
        scenarioId={state.scenarioId}
        onChange={(scenarioId) => dispatch({ type: 'setScenario', scenarioId })}
      />

      <header className="ps-header">
        <a className="ps-wordmark" href="#top" aria-label="ParkSync home">
          <span>P</span>
          <strong>ParkSync</strong>
        </a>
        <div className="ps-header__context">
          <GraduationCap size={18} />
          <span>Kennesaw State University · Campus OS</span>
        </div>
        <div className="ps-header__status">
          <span><Radio size={14} /> SIM FEED</span>
          <span><Activity size={14} /> {campus.name}</span>
        </div>
      </header>

      <main id="top">
        <Planner state={state} dispatch={dispatch} campus={campus} />
        <RecommendationList
          decision={decision}
          selectedMode={state.selectedMode}
          scenarioId={state.scenarioId}
          onSelect={(mode) => dispatch({ type: 'selectMode', mode })}
        />
        <CampusMap campus={campus} target={target} readings={readings} decision={decision} />
        <CommunityReports campus={campus} readings={readings} scenario={scenario} />
      </main>

      <footer className="ps-footer">
        <div className="ps-wordmark ps-wordmark--footer"><span>P</span><strong>ParkSync</strong></div>
        <p><BrainCircuit size={15} /> AI-powered campus mobility &amp; student flow engine</p>
        <small>Hackathon simulation · Not an official KSU parking, Uber, or Big Owl Bus service</small>
      </footer>
    </div>
  );
}
