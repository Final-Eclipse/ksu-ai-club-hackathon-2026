import type { SchedulePreset } from '../types';

export const PRESETS: readonly SchedulePreset[] = [
  {
    id: 'k-bio',
    label: 'BIOL · MWF · Science',
    persona: 'University Village resident driving back from Acworth',
    campusId: 'kennesaw',
    arrivalMin: 675,
    profile: { originLabel: 'Acworth', driveMin: 18, distanceMi: 9.5 },
    dormId: 'k-uv',
    classes: [
      { id: 'k-bio-2108', course: 'BIOL 2108', buildingId: 'k-science', room: 'SC 109', days: 'MWF', startMin: 750, endMin: 800 },
      { id: 'k-psy-1101', course: 'PSYC 1101', buildingId: 'k-socsci', room: 'SO 203', days: 'MWF', startMin: 840, endMin: 890 },
    ],
  },
  {
    id: 'k-psy',
    label: 'PSYC · TR · Social Sciences',
    persona: 'Commuter from Marietta',
    campusId: 'kennesaw',
    arrivalMin: 530,
    profile: { originLabel: 'Marietta', driveMin: 22, distanceMi: 11.2 },
    classes: [
      { id: 'k-psy-2210', course: 'PSYC 2210', buildingId: 'k-socsci', room: 'SO 1019', days: 'TR', startMin: 570, endMin: 645 },
      { id: 'k-chem-1211', course: 'CHEM 1211', buildingId: 'k-science', room: 'SC 214', days: 'TR', startMin: 660, endMin: 735 },
    ],
  },
  {
    id: 'm-eng',
    label: 'ENGR · MW · Atrium + ETC',
    persona: 'Hornet Village resident with a morning job in Smyrna',
    campusId: 'marietta',
    arrivalMin: 540,
    profile: { originLabel: 'Smyrna', driveMin: 15, distanceMi: 7 },
    dormId: 'm-hornet',
    classes: [
      { id: 'm-ee-2301', course: 'EE 2301', buildingId: 'm-atrium', room: 'J 202', days: 'MW', startMin: 600, endMin: 675 },
      { id: 'm-engr-1000', course: 'ENGR 1000', buildingId: 'm-etc', room: 'Q 110', days: 'MW', startMin: 780, endMin: 855 },
    ],
  },
];
