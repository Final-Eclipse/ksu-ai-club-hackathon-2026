import type { Dispatch } from 'react';
import {
  ArrowDownToLine,
  Building2,
  CalendarClock,
  CarFront,
  Clock3,
  MapPin,
  Minus,
  Plus,
  Route,
  UserRound,
} from 'lucide-react';
import { CAMPUSES } from '../data/campuses';
import { PRESETS } from '../data/presets';
import { toClassSessions } from '../engine/schedule';
import { formatClock, parseClock, toHHMM } from '../engine/time';
import type { Campus } from '../types';
import type { PlanAction, PlanState } from '../state/plan';
import { ScheduleImporter } from './ScheduleImporter';

interface PlannerProps {
  state: PlanState;
  dispatch: Dispatch<PlanAction>;
  campus: Campus;
}

export function Planner({ state, dispatch, campus }: PlannerProps) {
  return (
    <section className="ps-planner" aria-labelledby="ps-schedule-title">
      <div className="ps-section-label"><span>00</span> Schedule Sync</div>
      <div className="ps-planner__grid">
        <div className="ps-planner__intro">
          <p className="ps-kicker">Know the class. Model the whole trip.</p>
          <h1 id="ps-schedule-title">Your schedule becomes a <em>mobility decision.</em></h1>
          <p className="ps-planner__lede">
            ParkSync compares parking, rideshare, and Big Owl Bus against the class that matters next—not a generic campus destination.
          </p>
          <div className="ps-persona-card">
            <UserRound size={20} />
            <div>
              <span>Active student story</span>
              <strong>{PRESETS.find((preset) => preset.id === state.presetId)?.persona ?? 'Imported KSU schedule'}</strong>
            </div>
          </div>
        </div>

        <div className="ps-sync-card">
          <div className="ps-control-group">
            <span className="ps-control-label"><MapPin size={15} /> Campus</span>
            <div className="ps-segmented" role="group" aria-label="Campus">
              {(Object.keys(CAMPUSES) as Array<keyof typeof CAMPUSES>).map((campusId) => (
                <button
                  type="button"
                  key={campusId}
                  aria-pressed={state.campusId === campusId}
                  onClick={() => dispatch({ type: 'setCampus', campusId })}
                >
                  {CAMPUSES[campusId].name.replace(' Campus', '')}
                </button>
              ))}
            </div>
          </div>

          <div className="ps-control-group">
            <span className="ps-control-label"><CalendarClock size={15} /> Demo schedules</span>
            <div className="ps-preset-grid">
              {PRESETS.map((preset) => (
                <button
                  type="button"
                  key={preset.id}
                  aria-pressed={state.presetId === preset.id}
                  onClick={() => dispatch({ type: 'applyPreset', presetId: preset.id })}
                >
                  <span>{preset.campusId === 'kennesaw' ? 'K' : 'M'}</span>
                  <strong>{preset.label}</strong>
                  <small>{preset.profile.originLabel} · {preset.profile.driveMin} min drive</small>
                </button>
              ))}
            </div>
          </div>

          <div className="ps-control-group">
            <span className="ps-control-label"><Building2 size={15} /> Classes in this decision</span>
            <div className="ps-class-chips" role="group" aria-label="Select target class">
              {state.classes.map((session) => {
                const place = campus.places.find((candidate) => candidate.id === session.buildingId);
                return (
                  <button
                    type="button"
                    key={session.id}
                    aria-pressed={state.selectedClassId === session.id}
                    onClick={() => dispatch({ type: 'selectClass', classId: session.id })}
                  >
                    <strong>{session.course}</strong>
                    <span>{place?.short ?? session.buildingId} · {formatClock(session.startMin)}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="ps-arrival-row">
            <div className="ps-control-group">
              <span className="ps-control-label"><Clock3 size={15} /> Reach campus by</span>
              <div className="ps-time-stepper">
                <button
                  type="button"
                  aria-label="Move arrival 15 minutes earlier"
                  onClick={() => dispatch({ type: 'setArrival', arrivalMin: state.arrivalMin - 15 })}
                >
                  <Minus size={17} /> 15
                </button>
                <label>
                  <span className="ps-sr-only">Campus arrival time</span>
                  <input
                    type="time"
                    value={toHHMM(state.arrivalMin)}
                    onChange={(event) => {
                      const minute = parseClock(event.target.value);
                      if (minute !== null) dispatch({ type: 'setArrival', arrivalMin: minute });
                    }}
                  />
                  <strong>{formatClock(state.arrivalMin)}</strong>
                </label>
                <button
                  type="button"
                  aria-label="Move arrival 15 minutes later"
                  onClick={() => dispatch({ type: 'setArrival', arrivalMin: state.arrivalMin + 15 })}
                >
                  <Plus size={17} /> 15
                </button>
              </div>
            </div>

            <div className="ps-origin">
              <CarFront size={20} />
              <div><span>Starting in</span><strong>{state.profile.originLabel}</strong></div>
              <div><span>Baseline</span><strong>{state.profile.driveMin} min · {state.profile.distanceMi} mi</strong></div>
            </div>
          </div>

          <details className="ps-import-details">
            <summary><ArrowDownToLine size={15} /> Import another schedule</summary>
            <ScheduleImporter
              campus={campus}
              onImport={(meetings) => {
                const converted = toClassSessions(meetings, campus);
                dispatch({ type: 'importClasses', classes: converted.classes, notes: converted.notes });
              }}
            />
          </details>

          {state.importNotes.length > 0 && (
            <div className="ps-import-notes" role="status">
              <Route size={16} />
              <div>
                <strong>Import notes</strong>
                {state.importNotes.map((note) => <span key={note}>{note}</span>)}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
