import {
  ArrowUpRight,
  BusFront,
  CarFront,
  Check,
  CircleDollarSign,
  Clock3,
  Footprints,
  Gauge,
  MapPin,
  Route,
  Sparkles,
  TriangleAlert,
} from 'lucide-react';
import { formatClock } from '../engine/time';
import type { CommuteDecision, CommuteMode, ScenarioId } from '../types';
import { StatusBadge } from './StatusBadge';

interface RecommendationListProps {
  decision: CommuteDecision;
  selectedMode: CommuteMode | null;
  scenarioId: ScenarioId;
  onSelect: (mode: CommuteMode) => void;
}

export function RecommendationList({
  decision,
  selectedMode,
  scenarioId,
  onSelect,
}: RecommendationListProps) {
  const activeMode = selectedMode ?? decision.winner;
  const selectedTitle = decision.options.find((option) => option.mode === selectedMode)?.title;
  const winnerTitle = decision.options.find((option) => option.mode === decision.winner)?.title ?? decision.winner;

  return (
    <section className="ps-arrival" aria-labelledby="ps-arrival-title">
      <div className="ps-section-label"><span>01</span> Smart Arrival</div>
      <div className="ps-decision-banner">
        <div className="ps-decision-banner__icon"><Sparkles size={24} /></div>
        <div>
          <span>AI Decision Engine → {winnerTitle}</span>
          <h2 id="ps-arrival-title">{decision.explanation}</h2>
          {decision.fallback && (
            <small><TriangleAlert size={14} /> Fallback rule: deck &gt; 95% or rain/traffic</small>
          )}
        </div>
        <div className="ps-decision-banner__target">
          <span>Target</span>
          <strong>{decision.targetName}</strong>
        </div>
      </div>

      {selectedMode && (
        <div className="ps-choice-note" role="status">
          <Check size={16} /> You chose {selectedTitle} · AI suggests {winnerTitle}
        </div>
      )}

      <div className="ps-option-grid">
        {decision.options.map((option) => {
          const isWinner = option.mode === decision.winner;
          const isSelected = option.mode === activeMode;
          const ModeIcon = option.mode === 'drive' ? CarFront : option.mode === 'uber' ? MapPin : BusFront;
          return (
            <article
              key={isWinner ? `${scenarioId}-${decision.winner}` : option.mode}
              className={`ps-option-card ${isSelected ? 'ps-option-card--selected' : ''} ${!option.eligible ? 'ps-option-card--ineligible' : ''} ${isWinner ? 'ps-pop' : ''}`}
            >
              {isWinner && <span className="ps-ai-ribbon"><Sparkles size={13} /> AI PICK</span>}
              {!option.eligible && (
                <span className="ps-fallback-ribbon">
                  Fallback: {decision.fallback === 'deckFull' ? 'deck > 95%' : 'rain/traffic'}
                </span>
              )}

              <button
                type="button"
                className="ps-option-card__button"
                aria-pressed={isSelected}
                onClick={() => onSelect(option.mode)}
              >
                <span className="ps-option-card__heading">
                  <span className="ps-mode-icon"><ModeIcon size={22} /></span>
                  <span><small>{option.mode === 'drive' ? 'Personal vehicle' : option.mode === 'uber' ? 'Direct curb access' : 'Campus transit'}</small><strong>{option.title}</strong></span>
                  <span className="ps-radio-mark" aria-hidden="true" />
                </span>

                <span className="ps-option-time">
                  <strong>{option.totalMin}</strong>
                  <span>min total</span>
                  <small><Clock3 size={13} /> Arrive {formatClock(option.arriveMin)} · {option.slackMin} min slack</small>
                </span>

                {option.deck && (
                  <span className="ps-mode-detail">
                    <span className="ps-detail-topline">
                      <span><strong>{option.deck.deck.name}</strong><small>{option.deck.deck.levels} {option.deck.deck.levels === 1 ? 'level' : 'levels'} · {option.deck.deck.capacity.toLocaleString()} spaces</small></span>
                      <StatusBadge status={option.deck.reading.status} occupancy={option.deck.reading.occupancy} />
                    </span>
                    <span className="ps-camera-reading">
                      <Gauge size={15} /> Predicted {Math.round(option.deck.reading.predictedOccupancy * 100)}% · CV cam: {option.deck.reading.open} open (best L{option.deck.reading.bestLevel}) · {Math.round(option.deck.reading.cvConfidence * 100)}% conf
                    </span>
                    <span className="ps-detail-line"><Footprints size={15} /> Walk {option.walkMin} min to building</span>
                  </span>
                )}

                {option.uber && option.fareUsd && (
                  <span className="ps-mode-detail">
                    <span className="ps-detail-topline">
                      <span><strong>${option.fareUsd.low}–${option.fareUsd.high} <i>(SIM)</i></strong><small>Estimated one-way fare</small></span>
                      <span className={`ps-congestion ps-congestion--${option.uber.pin.congestion}`}>{option.uber.pin.congestion} curb flow</span>
                    </span>
                    <span className="ps-detail-line"><MapPin size={15} /> {option.uber.pin.name}</span>
                    <span className="ps-detail-line"><Footprints size={15} /> Walk {option.walkMin} min from drop-off</span>
                  </span>
                )}

                {option.shuttle && (
                  <span className="ps-mode-detail">
                    <span className="ps-detail-topline">
                      <span><strong>$0 · free shuttle lot</strong><small>{option.shuttle.route.name}</small></span>
                      <span className={`ps-load-pill ${option.shuttle.loadPct >= 95 ? 'ps-load-pill--full' : ''}`}>{option.shuttle.loadPct}% load (SIM)</span>
                    </span>
                    <span className="ps-shuttle-flow">
                      {option.shuttle.route.remoteLot} <b>→</b> bus every {option.shuttle.route.headwayMin} min <b>→</b> {option.shuttle.route.stopName} <b>→</b> walk {option.walkMin} min
                    </span>
                  </span>
                )}

                <span className="ps-leg-list">
                  {option.legs.map((leg) => (
                    <span key={leg.label}><i /> <span>{leg.label}</span><strong>{leg.minutes}m</strong></span>
                  ))}
                </span>

                <span className="ps-select-line">
                  <span>{isSelected ? 'Selected plan' : 'Choose this plan'}</span>
                  <Route size={16} />
                </span>
              </button>

              {option.uber && (
                <a
                  className="ps-uber-link"
                  href={option.uber.deepLink}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open in Uber <ArrowUpRight size={16} />
                </a>
              )}
              {option.mode === 'drive' && (
                <span className="ps-card-footnote"><CircleDollarSign size={14} /> Permit cost excluded</span>
              )}
            </article>
          );
        })}
      </div>
    </section>
  );
}
