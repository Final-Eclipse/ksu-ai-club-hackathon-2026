import { Building2, Camera, Layers3, MapPin, Navigation, ScanLine } from 'lucide-react';
import { projectFootprint, projectGeo, routePath, sequence } from '../engine/mapLayout';
import type { Campus, CommuteDecision, DeckReading, Place } from '../types';
import { StatusBadge } from './StatusBadge';

interface CampusMapProps {
  campus: Campus;
  target: Place;
  readings: DeckReading[];
  decision: CommuteDecision;
}

export function CampusMap({ campus, target, readings, decision }: CampusMapProps) {
  const winner = decision.options.find((option) => option.mode === decision.winner);
  const targetPoint = projectGeo(campus, target.geo);
  const arrivalPoint = winner ? projectGeo(campus, winner.arrivalPoint.geo) : targetPoint;

  return (
    <section className="ps-map-section" aria-labelledby="ps-map-title">
      <div className="ps-section-label"><span>02</span> Campus Flow Map</div>
      <div className="ps-section-heading">
        <div>
          <p className="ps-kicker">2.5D campus digital twin</p>
          <h2 id="ps-map-title">From arrival point to classroom.</h2>
        </div>
        <p>Geographic placement uses OpenStreetMap coordinates. Approximate locations carry an ≈ marker.</p>
      </div>

      <div className="ps-map-layout">
        <div className="ps-map-shell">
          <div className="ps-map-toolbar">
            <span><MapPin size={15} /> {campus.name}</span>
            <span><Navigation size={15} /> AI route: {winner?.title ?? 'Calculating'}</span>
            <span className="ps-sim-chip"><Camera size={14} /> SIMULATED SENSOR LAYER</span>
          </div>
          <svg className="ps-campus-map" viewBox="0 0 1000 600" role="img" aria-label={`${campus.name} mobility map with parking decks and destination`}>
            <defs>
              <pattern id={`ps-grid-${campus.id}`} width="32" height="32" patternUnits="userSpaceOnUse">
                <path d="M 32 0 L 0 0 0 32" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.16" />
              </pattern>
              <filter id={`ps-glow-${campus.id}`} x="-30%" y="-30%" width="160%" height="160%">
                <feGaussianBlur stdDeviation="5" result="blur" />
                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
            </defs>
            <rect className="ps-map-ground" width="1000" height="600" rx="18" />
            <rect className="ps-map-grid" width="1000" height="600" rx="18" fill={`url(#ps-grid-${campus.id})`} />
            <path className="ps-map-road" d="M40 340 C190 270 330 375 510 310 S790 220 960 292" />
            <path className="ps-map-road ps-map-road--thin" d="M175 28 C245 170 224 390 170 570" />
            <path className="ps-map-road ps-map-road--thin" d="M694 30 C620 180 670 390 780 565" />
            <path
              className="ps-map-route-glow"
              filter={`url(#ps-glow-${campus.id})`}
              d={routePath(arrivalPoint, targetPoint)}
            />
            <path className="ps-map-route" d={routePath(arrivalPoint, targetPoint)} />

            {campus.places.map((place) => {
              const point = projectGeo(campus, place.geo);
              const footprint = projectFootprint(place.footprint);
              const selected = place.id === target.id;
              return (
                <g
                  key={place.id}
                  className={`ps-map-building ${selected ? 'ps-map-building--target' : ''}`}
                  transform={`translate(${point.x} ${point.y})`}
                >
                  <polygon
                    className="ps-map-building__side"
                    points={`${-footprint.width / 2},${-footprint.depth / 2} ${footprint.width / 2},${-footprint.depth / 2} ${footprint.width / 2},${footprint.depth / 2} ${-footprint.width / 2},${footprint.depth / 2}`}
                    transform={`translate(0 ${footprint.height})`}
                  />
                  <polygon
                    className="ps-map-building__top"
                    points={`${-footprint.width / 2},${-footprint.depth / 2} ${footprint.width / 2},${-footprint.depth / 2} ${footprint.width / 2 + 10},${-footprint.depth / 2 - 7} ${-footprint.width / 2 + 10},${-footprint.depth / 2 - 7}`}
                    transform={`translate(0 ${-footprint.height})`}
                  />
                  <rect
                    className="ps-map-building__face"
                    x={-footprint.width / 2}
                    y={-footprint.depth / 2 - footprint.height}
                    width={footprint.width}
                    height={footprint.depth}
                    rx="4"
                  />
                  <text className="ps-map-label" y={footprint.depth / 2 + 19} textAnchor="middle">
                    {place.geoApprox ? '≈ ' : ''}{place.short}
                  </text>
                  {selected && <circle className="ps-target-pulse" cy={-footprint.height - footprint.depth / 2 - 11} r="7" />}
                </g>
              );
            })}

            {campus.decks.map((deck) => {
              const point = projectGeo(campus, deck.geo);
              const footprint = projectFootprint(deck.footprint);
              const reading = readings.find((candidate) => candidate.deckId === deck.id);
              return (
                <g key={deck.id} className="ps-map-deck" transform={`translate(${point.x} ${point.y})`}>
                  {sequence(deck.levels).map((levelIndex) => (
                    <rect
                      key={`${deck.id}-${levelIndex}`}
                      x={-footprint.width / 2}
                      y={-footprint.depth / 2 - levelIndex * 4}
                      width={footprint.width}
                      height={footprint.depth}
                      rx="4"
                    />
                  ))}
                  <text className="ps-map-label" y={footprint.depth / 2 + 19} textAnchor="middle">
                    {deck.geoApprox ? '≈ ' : ''}{deck.short} · {reading ? Math.round(reading.occupancy * 100) : 0}%
                  </text>
                </g>
              );
            })}

            <g className="ps-arrival-marker" transform={`translate(${arrivalPoint.x} ${arrivalPoint.y})`}>
              <circle r="13" />
              <Navigation size={16} x={-8} y={-8} />
            </g>
          </svg>
          <div className="ps-map-caption">
            <span><i className="ps-map-key ps-map-key--gold" /> Selected destination</span>
            <span><i className="ps-map-key ps-map-key--white" /> Campus place</span>
            <span><i className="ps-map-key ps-map-key--slate" /> Parking structure</span>
          </div>
        </div>

        <aside className="ps-deck-panel" aria-label="Simulated deck camera readings">
          <div className="ps-deck-panel__heading">
            <div><ScanLine size={20} /><span><strong>CV deck cameras</strong><small>Deterministic simulation · 15-min frame</small></span></div>
            <span className="ps-live-dot">SIM</span>
          </div>
          {campus.decks.map((deck) => {
            const reading = readings.find((candidate) => candidate.deckId === deck.id);
            if (!reading) return null;
            return (
              <article className="ps-deck-row" key={deck.id}>
                <div className="ps-deck-row__top">
                  <div><Building2 size={17} /><span><strong>{deck.name}</strong><small>{deck.kind} · {deck.levels} {deck.levels === 1 ? 'level' : 'levels'}</small></span></div>
                  <StatusBadge status={reading.status} occupancy={reading.occupancy} />
                </div>
                <div className="ps-open-count"><strong>{reading.open}</strong><span>open spaces</span><small>Best level: L{reading.bestLevel}</small></div>
                <div className="ps-level-strip" aria-label={`${deck.name} open spaces by level`}>
                  {reading.levels.map((level) => (
                    <span key={level.level} title={`Level ${level.level}: ${level.open} open`}>
                      <i style={{ height: `${Math.max(8, (level.open / Math.max(1, level.capacity)) * 100)}%` }} />
                      <small>L{level.level}</small>
                    </span>
                  ))}
                </div>
                <div className="ps-confidence"><Layers3 size={14} /> {Math.round(reading.cvConfidence * 100)}% simulated camera confidence</div>
              </article>
            );
          })}
        </aside>
      </div>
    </section>
  );
}
