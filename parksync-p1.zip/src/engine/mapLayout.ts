import type { Campus, Footprint, GeoPoint } from '../types';

export interface ProjectedPoint {
  x: number;
  y: number;
}

export interface ProjectedFootprint {
  width: number;
  depth: number;
  height: number;
}

export function projectGeo(campus: Campus, geo: GeoPoint): ProjectedPoint {
  return {
    x: 500 + (geo.lng - campus.center.lng) * 45_000,
    y: 300 - (geo.lat - campus.center.lat) * 45_000,
  };
}

export function projectFootprint(footprint: Footprint): ProjectedFootprint {
  return {
    width: Math.max(32, footprint.w * 0.8),
    depth: Math.max(22, footprint.d * 0.62),
    height: Math.max(2, footprint.h * 1.05),
  };
}

export function routePath(from: ProjectedPoint, to: ProjectedPoint): string {
  const bendX = (from.x + to.x) / 2;
  const bendY = Math.min(from.y, to.y) - 42;
  return `M ${from.x} ${from.y} Q ${bendX} ${bendY} ${to.x} ${to.y}`;
}

export function sequence(count: number): number[] {
  const values: number[] = [];
  for (let index = 0; index < count; index += 1) values.push(index);
  return values;
}
