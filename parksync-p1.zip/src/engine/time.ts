function normalizedMinute(minute: number): number {
  const rounded = Math.round(minute);
  return ((rounded % 1440) + 1440) % 1440;
}

export function formatClock(minute: number): string {
  const normalized = normalizedMinute(minute);
  const hour24 = Math.floor(normalized / 60);
  const minutePart = normalized % 60;
  const suffix = hour24 >= 12 ? 'PM' : 'AM';
  const hour12 = hour24 % 12 || 12;
  return `${hour12}:${String(minutePart).padStart(2, '0')} ${suffix}`;
}

export function parseClock(text: string): number | null {
  const normalized = text.trim().toLowerCase();
  if (normalized === 'noon') return 720;

  const twelveHour = normalized.match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)$/);
  if (twelveHour) {
    const hour = Number(twelveHour[1]);
    const minute = Number(twelveHour[2] ?? '0');
    if (hour < 1 || hour > 12 || minute < 0 || minute > 59) return null;
    return (hour % 12) * 60 + minute + (twelveHour[3] === 'pm' ? 720 : 0);
  }

  const twentyFourHour = normalized.match(/^(\d{1,2}):(\d{2})$/);
  if (twentyFourHour) {
    const hour = Number(twentyFourHour[1]);
    const minute = Number(twentyFourHour[2]);
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return hour * 60 + minute;
  }

  return null;
}

export function toHHMM(minute: number): string {
  const normalized = normalizedMinute(minute);
  const hour = Math.floor(normalized / 60);
  const minutePart = normalized % 60;
  return `${String(hour).padStart(2, '0')}:${String(minutePart).padStart(2, '0')}`;
}
